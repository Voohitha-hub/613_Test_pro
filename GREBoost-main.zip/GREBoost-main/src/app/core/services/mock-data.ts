import { User, Course } from '../models/user.model';

// Mock Users with different roles and passwords
export const MOCK_USERS: User[] = [
  {
    id: '1',
    email: 'student@example.com',
    name: 'John Student',
    role: 'student'
  },
  {
    id: '2',
    email: 'instructor@example.com',
    name: 'Jane Instructor',
    role: 'instructor'
  },
  {
    id: '3',
    email: 'admin@example.com',
    name: 'Admin User',
    role: 'admin'
  }
];

// Mock Courses with detailed content
export const MOCK_COURSES: Course[] = [
  {
    id: '1',
    name: 'GRE Quantitative Reasoning',
    description: 'Master GRE math concepts and problem-solving strategies',
    duration: '8 weeks',
    instructorId: '2',
    instructorName: 'Jane Instructor',
    enrolledStudents: 25,
    content: {
      chapters: [
        {
          id: '1',
          title: 'Introduction to GRE Math',
          order: 1,
          lecture: {
            id: 'v1',
            title: 'GRE Math Overview',
            videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            description: 'Comprehensive overview of GRE Quantitative section'
          },
          slides: {
            id: 's1',
            title: 'GRE Math Introduction Slides',
            fileUrl: 'data:application/pdf;base64,JVBERi0...'
          },
          quiz: {
            id: 'q1',
            title: 'Introduction Quiz',
            questions: [
              {
                id: 'q1_1',
                text: 'What is the main focus of GRE Quantitative section?',
                options: [
                  'Basic arithmetic',
                  'Advanced calculus',
                  'Problem-solving and quantitative reasoning',
                  'Theoretical mathematics'
                ],
                correctAnswers: ['Problem-solving and quantitative reasoning']
              }
            ]
          }
        },
        {
          id: '2',
          title: 'Arithmetic and Number Properties',
          order: 2,
          lecture: {
            id: 'v2',
            title: 'Understanding Number Properties',
            videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            description: 'Deep dive into arithmetic concepts and number properties essential for GRE'
          },
          slides: {
            id: 's2',
            title: 'Number Properties Slides',
            fileUrl: 'data:application/pdf;base64,JVBERi0...'
          },
          quiz: {
            id: 'q2',
            title: 'Number Properties Quiz',
            questions: [
              {
                id: 'q2_1',
                text: 'Which of the following is always divisible by 2?',
                options: [
                  'Sum of two odd numbers',
                  'Product of two odd numbers',
                  'Sum of two even numbers',
                  'Difference of two even numbers'
                ],
                correctAnswers: ['Sum of two odd numbers']
              }
            ]
          }
        },
        {
          id: '3',
          title: 'Algebra and Functions',
          order: 3,
          lecture: {
            id: 'v3',
            title: 'Mastering Algebra',
            videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
            description: 'Learn essential algebraic concepts and function properties'
          },
          slides: {
            id: 's3',
            title: 'Algebra Fundamentals',
            fileUrl: 'data:application/pdf;base64,JVBERi0...'
          },
          quiz: {
            id: 'q3',
            title: 'Algebra Quiz',
            questions: [
              {
                id: 'q3_1',
                text: 'What is the domain of f(x) = √x?',
                options: [
                  'All real numbers',
                  'Non-negative real numbers',
                  'Positive real numbers',
                  'Negative real numbers'
                ],
                correctAnswers: ['Non-negative real numbers']
              }
            ]
          }
        }
      ]
    }
  }
];