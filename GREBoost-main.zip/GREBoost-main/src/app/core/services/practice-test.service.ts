import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { PracticeTest, Question, TestAttempt } from '../models/user.model';
import * as XLSX from 'xlsx';

@Injectable({
  providedIn: 'root'
})
export class PracticeTestService {
  constructor(private api: ApiService) {}

  getTests(courseId: string): Observable<PracticeTest[]> {
    return this.api.get<PracticeTest[]>(`/tests/course/${courseId}`);
  }

  getTestById(courseId: string, testId: string): Observable<PracticeTest> {
    return this.api.get<PracticeTest>(`/tests/course/${courseId}/${testId}`);
  }

  createTest(test: Partial<PracticeTest> & { courseId: string }): Observable<PracticeTest> {
    return this.api.post<PracticeTest>(`/tests/course/${test.courseId}`, test);
  }

  processExcelFile(file: File): Promise<Question[]> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const rows: any[] = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });

          const questions: Question[] = rows.slice(1).map((row, index) => ({
            id: Math.random().toString(36).substr(2, 9),
            text: row[0],
            options: [row[1], row[2], row[3], row[4]],
            correctAnswers: row[5].split(',').map((ans: string) => ans.trim()),
            selectedAnswers: []
          }));

          resolve(questions);
        } catch (error) {
          reject(new Error('Error processing Excel file'));
        }
      };
      reader.onerror = () => reject(new Error('Error reading file'));
      reader.readAsArrayBuffer(file);
    });
  }

  submitTestAttempt(courseId: string, testId: string, attempt: Partial<TestAttempt>): Observable<void> {
    return this.api.post<void>(`/tests/${testId}/attempt`, {
      ...attempt,
      courseId
    });
  }

  deleteTest(courseId: string, testId: string): Observable<void> {
    return this.api.delete<void>(`/tests/${testId}`);
  }
}