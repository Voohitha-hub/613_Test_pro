import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Course, Chapter } from '../models/user.model';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  constructor(
    private api: ApiService,
    private authService: AuthService
  ) {}

  getAllCourses(): Observable<Course[]> {
    return this.api.get<Course[]>('/courses');
  }

  getAssignedCourses(): Observable<Course[]> {
    const instructorId = this.authService.getCurrentUserValue()?.id;
    console.log('Fetching assigned courses for user...' + instructorId);
    return this.api.get<Course[]>('/courses/instructor/assigned');

  }

  getEnrolledCourses(): Observable<Course[]> {
    return this.api.get<Course[]>('/courses/enrolled');
  }

  getAvailableCourses(): Observable<Course[]> {
    return this.api.get<Course[]>('/courses/available');
  }

  getCourseById(id: string): Observable<Course> {
    return this.api.get<Course>(`/courses/${id}`);
  }

  createCourse(courseData: Partial<Course>): Observable<Course> {
    return this.api.post<Course>('/courses', courseData);
  }

  updateCourse(id: string, courseData: Partial<Course>): Observable<Course> {
    return this.api.put<Course>(`/courses/${id}`, courseData);
  }

  deleteCourse(id: string): Observable<void> {
    return this.api.delete<void>(`/courses/${id}`);
  }

  addChapter(courseId: string, chapter: Chapter): Observable<Course> {
    console.log('Adding chapter to course...' + courseId);
    return this.api.post<Course>(`/courses/${courseId}/chapters`, chapter);
  }

  removeChapter(courseId: string, chapterId: string): Observable<Course> {
    return this.api.delete<Course>(`/courses/${courseId}/chapters/${chapterId}`);
  }

  enrollInCourse(courseId: string): Observable<void> {
    return this.api.post<void>(`/courses/${courseId}/enroll`, {});
  }

  validateYouTubeUrl(url: string): boolean {
    const pattern = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+$/;
    return pattern.test(url);
  }

  convertToEmbedUrl(url: string): string {
    const videoId = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([^&?]+)/);
    return videoId ? `https://www.youtube.com/embed/${videoId[1]}` : url;
  }

  async processSlidesPDF(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        resolve(e.target.result);
      };
      reader.onerror = () => reject(new Error('Error reading PDF file'));
      reader.readAsDataURL(file);
    });
  }
}