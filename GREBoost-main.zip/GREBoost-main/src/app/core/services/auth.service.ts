import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { User } from '../models/user.model';
import { ApiService } from './api.service';

interface LoginResponse {
  token: string;
  user: User;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUser: User | null = null;

  constructor(
    private router: Router,
    private api: ApiService
  ) {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      this.currentUser = JSON.parse(storedUser);
    }
  }

  login(email: string, password: string): Observable<LoginResponse> {
    return this.api.post<LoginResponse>('/auth/login', { email, password }).pipe(
      tap(response => {
        this.currentUser = response.user;
        localStorage.setItem('user', JSON.stringify(response.user));
        localStorage.setItem('token', response.token);
        this.router.navigate(['/dashboard']);
      }),
      catchError(error => {
        console.error('Login error:', error);
        return throwError(() => new Error('Invalid credentials'));
      })
    );
  }

  logout(): void {
    this.currentUser = null;
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }

  signup(userData: any): Observable<{ message: string }> {
    return this.api.post<{ message: string }>('/auth/signup', userData).pipe(
      tap(() => {
        this.router.navigate(['/login']);
      }),
      catchError(error => {
        console.error('Signup error:', error);
        return throwError(() => error);
      })
    );
  }

  createInstructorRequest(userData: any): Observable<{ message: string }> {
    return this.api.post<{ message: string }>('/auth/signup', { ...userData, role: 'instructor' }).pipe(
      tap(() => {
        this.router.navigate(['/login']);
      }),
      catchError(error => {
        console.error('Instructor request error:', error);
        return throwError(() => error);
      })
    );
  }

  isAuthenticated(): boolean {
    return !!this.currentUser && !!localStorage.getItem('token');
  }

  getCurrentUserValue(): User | null {
    return this.currentUser;
  }

  hasRole(role: string): boolean {
    return this.currentUser?.role === role;
  }
}