import { TestBed } from '@angular/core/testing';
import { FlashcardService } from './flashcard.service';
import { ApiService } from './api.service';
import { of } from 'rxjs';

describe('FlashcardService', () => {
  let service: FlashcardService;
  let apiService: jasmine.SpyObj<ApiService>;

  const mockFlashcards = [
    { id: 1, question: 'Test Question', answer: 'Test Answer', isFlipped: false }
  ];

  beforeEach(() => {
    const apiSpy = jasmine.createSpyObj('ApiService', ['get', 'post', 'delete']);
    apiSpy.get.and.returnValue(of(mockFlashcards));
    apiSpy.post.and.returnValue(of(mockFlashcards[0]));
    apiSpy.delete.and.returnValue(of(void 0));

    TestBed.configureTestingModule({
      providers: [
        FlashcardService,
        { provide: ApiService, useValue: apiSpy }
      ]
    });
    service = TestBed.inject(FlashcardService);
    apiService = TestBed.inject(ApiService) as jasmine.SpyObj<ApiService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get flashcards for a course', () => {
    service.getFlashcards('1').subscribe(flashcards => {
      expect(flashcards).toEqual(mockFlashcards);
    });
    expect(apiService.get).toHaveBeenCalledWith('/flashcards/course/1');
  });

  it('should create a flashcard', () => {
    const newFlashcard = {
      courseId: '1',
      question: 'New Question',
      answer: 'New Answer'
    };
    service.createFlashcard(newFlashcard).subscribe(flashcard => {
      expect(flashcard).toEqual(mockFlashcards[0]);
    });
    expect(apiService.post).toHaveBeenCalledWith('/flashcards/course/1', {
      question: newFlashcard.question,
      answer: newFlashcard.answer
    });
  });

  it('should delete a flashcard', () => {
    service.deleteFlashcard(1).subscribe();
    expect(apiService.delete).toHaveBeenCalledWith('/flashcards/1');
  });
});