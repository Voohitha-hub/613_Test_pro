import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { Announcement } from '../models/user.model';

const MOCK_ANNOUNCEMENTS: { [key: string]: Announcement[] } = {
  '1': [
    {
      id: '1',
      courseId: '1',
      title: 'Welcome to GRE Quantitative Reasoning!',
      content: 'Welcome to our comprehensive GRE preparation course! Please review the course materials and schedule. We will begin with fundamental concepts and progressively move to more advanced topics.',
      date: '2024-02-17',
      createdBy: 'Jane Instructor'
    },
    {
      id: '2',
      courseId: '1',
      title: 'Practice Test Schedule Update',
      content: 'I have added three new practice tests focusing on arithmetic, algebra, and geometry. These tests will help you assess your progress and identify areas that need more attention. Make sure to attempt them after completing the respective modules.',
      date: '2024-02-18',
      createdBy: 'Jane Instructor'
    },
    {
      id: '3',
      courseId: '1',
      title: 'Live Q&A Session This Weekend',
      content: 'Join us this Saturday at 10 AM EST for a live Q&A session where we\'ll discuss common challenges in the Quantitative section and strategies to overcome them. Bring your questions!',
      date: '2024-02-19',
      createdBy: 'Jane Instructor'
    },
    {
      id: '4',
      courseId: '1',
      title: 'New Study Materials Available',
      content: 'I\'ve uploaded additional practice problems and detailed solutions for the Number Properties section. You can find them in the course content under Chapter 2. These problems are specifically designed to help you tackle the more challenging questions you might encounter on the actual GRE.',
      date: '2024-02-20',
      createdBy: 'Jane Instructor'
    }
  ]
};

@Injectable({
  providedIn: 'root'
})
export class AnnouncementService {
  private announcementsSubject = new BehaviorSubject<{
    [key: string]: Announcement[];
  }>(MOCK_ANNOUNCEMENTS);

  getAnnouncements(courseId: string): Observable<Announcement[]> {
    return this.announcementsSubject.pipe(
      map((announcements) => announcements[courseId] || []),
      delay(500)
    );
  }

  createAnnouncement(
    announcement: Partial<Announcement> & { courseId: string }
  ): Observable<Announcement> {
    const currentAnnouncements = this.announcementsSubject.value;
    const newAnnouncement: Announcement = {
      id: Math.random().toString(36).substr(2, 9),
      courseId: announcement.courseId,
      title: announcement.title || '',
      content: announcement.content || '',
      date: new Date().toISOString(),
      createdBy: announcement.createdBy || ''
    };

    currentAnnouncements[announcement.courseId] = [
      ...(currentAnnouncements[announcement.courseId] || []),
      newAnnouncement
    ];

    this.announcementsSubject.next(currentAnnouncements);
    return of(newAnnouncement).pipe(delay(500));
  }

  deleteAnnouncement(courseId: string, announcementId: string): Observable<void> {
    const currentAnnouncements = this.announcementsSubject.value;
    if (currentAnnouncements[courseId]) {
      currentAnnouncements[courseId] = currentAnnouncements[courseId].filter(
        (a) => a.id !== announcementId
      );
      this.announcementsSubject.next(currentAnnouncements);
    }
    return of(void 0).pipe(delay(500));
  }
}