import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Flashcard } from '../../features/courses/components/flashcard/flashcard.component';

@Injectable({
  providedIn: 'root'
})
export class FlashcardService {
  constructor(private api: ApiService) {}

  getFlashcards(courseId: string): Observable<Flashcard[]> {
    return this.api.get<Flashcard[]>(`/flashcards/course/${courseId}`);
  }

  createFlashcard(flashcard: Partial<Flashcard> & { courseId: string }): Observable<Flashcard> {
    return this.api.post<Flashcard>(`/flashcards/course/${flashcard.courseId}`, {
      question: flashcard.question,
      answer: flashcard.answer
    });
  }

  deleteFlashcard(id: number): Observable<void> {
    return this.api.delete<void>(`/flashcards/${id}`);
  }
}