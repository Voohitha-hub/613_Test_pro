import { TestBed } from '@angular/core/testing';
import { RequestService } from './request.service';
import { Request } from '../models/user.model';

describe('RequestService', () => {
  let service: RequestService;

  const mockRequest: Request = {
    id: '1',
    type: 'instructor_account',
    status: 'pending',
    date: '2024-02-20',
    user_data: {
      name: 'Test User',
      email: 'test@example.com',
      role: 'instructor'
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RequestService]
    });
    service = TestBed.inject(RequestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get pending requests', (done) => {
    service.getPendingRequests().subscribe(requests => {
      expect(requests.length).toBeGreaterThan(0);
      expect(requests[0].status).toBe('pending');
      done();
    });
  });

  it('should create a new request', (done) => {
    const newRequest = {
      type: 'instructor_account' as const,
      user_data: {
        name: 'New User',
        email: 'new@example.com',
        role: 'instructor'
      }
    };

    service.createRequest(newRequest).subscribe(() => {
      service.getPendingRequests().subscribe(requests => {
        const createdRequest = requests.find(r => r.user_data.email === newRequest.user_data.email);
        expect(createdRequest).toBeTruthy();
        expect(createdRequest?.status).toBe('pending');
        done();
      });
    });
  });

  it('should approve a request', (done) => {
    service.approveRequest('1').subscribe(() => {
      service.getPendingRequests().subscribe(requests => {
        const approvedRequest = requests.find(r => r.id === '1');
        expect(approvedRequest?.status).toBe('approved');
        done();
      });
    });
  });

  it('should deny a request', (done) => {
    service.denyRequest('1').subscribe(() => {
      service.getPendingRequests().subscribe(requests => {
        const deniedRequest = requests.find(r => r.id === '1');
        expect(deniedRequest?.status).toBe('denied');
        done();
      });
    });
  });
});