import { TestBed } from '@angular/core/testing';
import { AnnouncementService } from './announcement.service';
import { Announcement } from '../models/user.model';

describe('AnnouncementService', () => {
  let service: AnnouncementService;

  const mockAnnouncement: Announcement = {
    id: '1',
    courseId: '1',
    title: 'Test Announcement',
    content: 'Test Content',
    date: '2024-02-20',
    createdBy: 'Test Instructor'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AnnouncementService]
    });
    service = TestBed.inject(AnnouncementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get announcements for a course', (done) => {
    service.getAnnouncements('1').subscribe(announcements => {
      expect(announcements.length).toBeGreaterThan(0);
      expect(announcements[0].courseId).toBe('1');
      done();
    });
  });

  it('should create a new announcement', (done) => {
    const newAnnouncement = {
      courseId: '1',
      title: 'New Announcement',
      content: 'New Content',
      createdBy: 'Test Instructor'
    };

    service.createAnnouncement(newAnnouncement).subscribe(announcement => {
      expect(announcement.title).toBe(newAnnouncement.title);
      expect(announcement.content).toBe(newAnnouncement.content);
      expect(announcement.courseId).toBe(newAnnouncement.courseId);
      done();
    });
  });

  it('should delete an announcement', (done) => {
    service.deleteAnnouncement('1', '1').subscribe(() => {
      service.getAnnouncements('1').subscribe(announcements => {
        const deletedAnnouncement = announcements.find(a => a.id === '1');
        expect(deletedAnnouncement).toBeUndefined();
        done();
      });
    });
  });

  it('should handle empty course announcements', (done) => {
    service.getAnnouncements('non-existent').subscribe(announcements => {
      expect(announcements).toEqual([]);
      done();
    });
  });
});