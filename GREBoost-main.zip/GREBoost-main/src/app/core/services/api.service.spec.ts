import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ApiService } from './api.service';
import { environment } from '../../../environments/environment';

describe('ApiService', () => {
  let service: ApiService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ApiService]
    });
    service = TestBed.inject(ApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('HTTP Methods', () => {
    const testUrl = '/test';
    const testData = { id: 1, name: 'Test' };

    it('should perform GET request', () => {
      service.get(testUrl).subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}${testUrl}`);
      expect(req.request.method).toBe('GET');
    });

    it('should perform POST request', () => {
      service.post(testUrl, testData).subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}${testUrl}`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(testData);
    });

    it('should perform PUT request', () => {
      service.put(testUrl, testData).subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}${testUrl}`);
      expect(req.request.method).toBe('PUT');
      expect(req.request.body).toEqual(testData);
    });

    it('should perform DELETE request', () => {
      service.delete(testUrl).subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}${testUrl}`);
      expect(req.request.method).toBe('DELETE');
    });
  });

  describe('Error Handling', () => {
    it('should handle client-side errors', (done) => {
      service.get('/test').subscribe({
        error: (error) => {
          expect(error.message).toBe('Network error');
          done();
        }
      });

      const req = httpMock.expectOne(`${environment.apiUrl}/test`);
      req.error(new ErrorEvent('Network error'));
    });

    it('should handle server-side errors', (done) => {
      service.get('/test').subscribe({
        error: (error) => {
          expect(error.message).toBe('Server error');
          done();
        }
      });

      const req = httpMock.expectOne(`${environment.apiUrl}/test`);
      req.flush({ message: 'Server error' }, { status: 500, statusText: 'Server Error' });
    });
  });

  describe('Headers', () => {
    it('should include auth token if available', () => {
      localStorage.setItem('token', 'test-token');
      service.get('/test').subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}/test`);
      expect(req.request.headers.get('Authorization')).toBe('Bearer test-token');
      localStorage.removeItem('token');
    });

    it('should not include auth token if not available', () => {
      localStorage.removeItem('token');
      service.get('/test').subscribe();
      const req = httpMock.expectOne(`${environment.apiUrl}/test`);
      expect(req.request.headers.get('Authorization')).toBe('');
    });
  });
});