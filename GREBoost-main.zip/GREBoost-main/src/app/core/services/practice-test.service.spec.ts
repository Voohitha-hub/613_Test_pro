import { TestBed } from '@angular/core/testing';
import { PracticeTestService } from './practice-test.service';
import { ApiService } from './api.service';
import { of } from 'rxjs';
import { PracticeTest, Question } from '../models/user.model';

describe('PracticeTestService', () => {
  let service: PracticeTestService;
  let apiService: jasmine.SpyObj<ApiService>;

  const mockTest: PracticeTest = {
    id: '1',
    courseId: '1',
    title: 'Test Quiz',
    description: 'Test Description',
    duration: 60,
    questions: [
      {
        id: 'q1',
        text: 'Test Question',
        options: ['A', 'B', 'C'],
        correctAnswers: ['A'],
        selectedAnswers: []
      }
    ],
    createdAt: '2024-02-20T00:00:00Z',
    attempts: []
  };

  beforeEach(() => {
    const apiSpy = jasmine.createSpyObj('ApiService', ['get', 'post', 'delete']);
    apiSpy.get.and.returnValue(of([mockTest]));
    apiSpy.post.and.returnValue(of(mockTest));
    apiSpy.delete.and.returnValue(of(void 0));

    TestBed.configureTestingModule({
      providers: [
        PracticeTestService,
        { provide: ApiService, useValue: apiSpy }
      ]
    });
    service = TestBed.inject(PracticeTestService);
    apiService = TestBed.inject(ApiService) as jasmine.SpyObj<ApiService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get tests for a course', () => {
    service.getTests('1').subscribe(tests => {
      expect(tests).toEqual([mockTest]);
    });
    expect(apiService.get).toHaveBeenCalledWith('/tests/course/1');
  });

  it('should get test by id', () => {
    service.getTestById('1', '1').subscribe(test => {
      expect(test).toEqual(mockTest);
    });
    expect(apiService.get).toHaveBeenCalledWith('/tests/course/1/1');
  });

  it('should create a test', () => {
    const newTest = {
      courseId: '1',
      title: 'New Test',
      description: 'New Description',
      duration: 30
    };
    service.createTest(newTest).subscribe(test => {
      expect(test).toEqual(mockTest);
    });
    expect(apiService.post).toHaveBeenCalledWith('/tests/course/1', newTest);
  });

  it('should submit test attempt', () => {
    const attempt = {
      startTime: '2024-02-20T10:00:00Z',
      endTime: '2024-02-20T11:00:00Z',
      score: 80,
      answers: []
    };
    service.submitTestAttempt('1', '1', attempt).subscribe();
    expect(apiService.post).toHaveBeenCalledWith('/tests/1/attempt', {
      ...attempt,
      courseId: '1'
    });
  });

  it('should delete a test', () => {
    service.deleteTest('1', '1').subscribe();
    expect(apiService.delete).toHaveBeenCalledWith('/tests/1');
  });

  describe('Excel File Processing', () => {
    it('should process Excel file correctly', async () => {
      const mockFile = new File([''], 'test.xlsx');
      // Create a partial question object for type-safe comparison
      const expectedQuestion: Partial<Question> = {
        text: 'Question 1',
        options: ['A', 'B', 'C', 'D'],
        correctAnswers: ['A'],
        selectedAnswers: []
      };

      // Mock the XLSX.read and XLSX.utils.sheet_to_json functions
      const mockXLSX = {
        read: jasmine.createSpy().and.returnValue({
          SheetNames: ['Sheet1'],
          Sheets: {
            Sheet1: {}
          }
        }),
        utils: {
          sheet_to_json: jasmine.createSpy().and.returnValue([
            ['Question 1', 'A', 'B', 'C', 'D', 'A']
          ])
        }
      };
      (window as any).XLSX = mockXLSX;

      const questions = await service.processExcelFile(mockFile);
      expect(questions.length).toBe(1);
      // Use jasmine.objectContaining for partial object matching
      expect(questions[0]).toEqual(jasmine.objectContaining(expectedQuestion));
    });

    it('should handle Excel processing errors', async () => {
      const mockFile = new File([''], 'test.xlsx');
      const mockError = new Error('Excel processing error');
      
      // Mock XLSX to throw an error
      const mockXLSX = {
        read: jasmine.createSpy().and.throwError(mockError)
      };
      (window as any).XLSX = mockXLSX;

      await expectAsync(service.processExcelFile(mockFile))
        .toBeRejectedWith(new Error('Error processing Excel file'));
    });
  });
});