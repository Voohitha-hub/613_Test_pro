import { TestBed } from '@angular/core/testing';
import { CourseService } from './course.service';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { Course } from '../models/user.model';
import { of } from 'rxjs';

describe('CourseService', () => {
  let service: CourseService;
  let apiService: jasmine.SpyObj<ApiService>;
  let authService: jasmine.SpyObj<AuthService>;

  const mockCourse: Course = {
    id: '1',
    name: 'Test Course',
    description: 'Test Description',
    duration: '8 weeks',
    instructorId: '1',
    instructorName: 'Test Instructor',
    enrolledStudents: 0,
    content: {
      chapters: []
    }
  };

  beforeEach(() => {
    const apiSpy = jasmine.createSpyObj('ApiService', ['get', 'post', 'put', 'delete']);
    const authSpy = jasmine.createSpyObj('AuthService', ['getCurrentUserValue']);

    apiSpy.get.and.returnValue(of([mockCourse]));
    apiSpy.post.and.returnValue(of(mockCourse));
    apiSpy.put.and.returnValue(of(mockCourse));
    apiSpy.delete.and.returnValue(of(void 0));
    authSpy.getCurrentUserValue.and.returnValue({ id: '1', role: 'instructor' });

    TestBed.configureTestingModule({
      providers: [
        CourseService,
        { provide: ApiService, useValue: apiSpy },
        { provide: AuthService, useValue: authSpy }
      ]
    });

    service = TestBed.inject(CourseService);
    apiService = TestBed.inject(ApiService) as jasmine.SpyObj<ApiService>;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('Course Management', () => {
    it('should get all courses', () => {
      service.getAllCourses().subscribe(courses => {
        expect(courses).toEqual([mockCourse]);
      });
      expect(apiService.get).toHaveBeenCalledWith('/courses');
    });

    it('should get assigned courses', () => {
      service.getAssignedCourses().subscribe(courses => {
        expect(courses).toEqual([mockCourse]);
      });
      expect(apiService.get).toHaveBeenCalledWith('/courses');
    });

    it('should get enrolled courses', () => {
      service.getEnrolledCourses().subscribe(courses => {
        expect(courses).toEqual([mockCourse]);
      });
      expect(apiService.get).toHaveBeenCalledWith('/courses/enrolled');
    });

    it('should get available courses', () => {
      service.getAvailableCourses().subscribe(courses => {
        expect(courses).toEqual([mockCourse]);
      });
      expect(apiService.get).toHaveBeenCalledWith('/courses/available');
    });

    it('should get course by id', () => {
      service.getCourseById('1').subscribe(course => {
        expect(course).toEqual(mockCourse);
      });
      expect(apiService.get).toHaveBeenCalledWith('/courses/1');
    });

    it('should create course', () => {
      const newCourse = {
        name: 'New Course',
        description: 'New Description',
        duration: '4 weeks'
      };
      service.createCourse(newCourse).subscribe(course => {
        expect(course).toEqual(mockCourse);
      });
      expect(apiService.post).toHaveBeenCalledWith('/courses', newCourse);
    });

    it('should update course', () => {
      const updateData = { name: 'Updated Course' };
      service.updateCourse('1', updateData).subscribe(course => {
        expect(course).toEqual(mockCourse);
      });
      expect(apiService.put).toHaveBeenCalledWith('/courses/1', updateData);
    });

    it('should delete course', () => {
      service.deleteCourse('1').subscribe();
      expect(apiService.delete).toHaveBeenCalledWith('/courses/1');
    });
  });

  describe('Chapter Management', () => {
    const mockChapter = {
      id: '1',
      title: 'Test Chapter',
      order: 1,
      lecture: {
        id: '1',
        title: 'Test Lecture',
        videoUrl: 'https://example.com',
        description: 'Test Description'
      }
    };

    it('should add chapter', () => {
      service.addChapter('1', mockChapter).subscribe(course => {
        expect(course).toEqual(mockCourse);
      });
      expect(apiService.post).toHaveBeenCalledWith('/courses/1/chapters', mockChapter);
    });

    it('should remove chapter', () => {
      service.removeChapter('1', '1').subscribe(course => {
        expect(course).toEqual(mockCourse);
      });
      expect(apiService.delete).toHaveBeenCalledWith('/courses/1/chapters/1');
    });
  });

  describe('Course Enrollment', () => {
    it('should enroll in course', () => {
      service.enrollInCourse('1').subscribe();
      expect(apiService.post).toHaveBeenCalledWith('/courses/1/enroll', {});
    });
  });

  describe('URL Validation', () => {
    it('should validate YouTube URLs', () => {
      expect(service.validateYouTubeUrl('https://youtube.com/watch?v=123')).toBeTrue();
      expect(service.validateYouTubeUrl('https://youtu.be/123')).toBeTrue();
      expect(service.validateYouTubeUrl('invalid-url')).toBeFalse();
    });

    it('should convert to embed URL', () => {
      expect(service.convertToEmbedUrl('https://youtube.com/watch?v=123'))
        .toBe('https://youtube.com/embed/123');
      expect(service.convertToEmbedUrl('https://youtu.be/123'))
        .toBe('https://youtube.com/embed/123');
    });
  });

  describe('File Processing', () => {
    it('should process slides PDF', async () => {
      const file = new File(['test'], 'test.pdf', { type: 'application/pdf' });
      const result = await service.processSlidesPDF(file);
      expect(result).toMatch(/^data:/);
    });
  });
});