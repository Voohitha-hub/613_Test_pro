import { TestBed } from '@angular/core/testing';
import { ThemeService } from './theme.service';
import { BehaviorSubject } from 'rxjs';

describe('ThemeService', () => {
  let service: ThemeService;

  beforeEach(() => {
    localStorage.clear();
    TestBed.configureTestingModule({
      providers: [ThemeService]
    });
    service = TestBed.inject(ThemeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('toggleTheme', () => {
    it('should toggle dark mode', (done) => {
      service.darkMode$.subscribe(initialState => {
        service.toggleTheme();
        service.darkMode$.subscribe(newState => {
          expect(newState).toBe(!initialState);
          done();
        });
      });
    });

    it('should update localStorage', () => {
      service.toggleTheme();
      expect(localStorage.getItem('darkMode')).toBe('true');
      service.toggleTheme();
      expect(localStorage.getItem('darkMode')).toBe('false');
    });

    it('should update document class', (done) => {
      service.darkMode$.subscribe(isDark => {
        expect(document.documentElement.classList.contains('dark')).toBe(isDark);
        done();
      });
    });
  });
});