import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Request } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class RequestService {
  constructor(private api: ApiService) {}

  getPendingRequests(): Observable<Request[]> {
    return this.api.get<Request[]>('/requests/pending');
  }

  approveRequest(requestId: string): Observable<void> {
    return this.api.post<void>(`/requests/${requestId}/approve`, {});
  }

  denyRequest(requestId: string): Observable<void> {
    return this.api.post<void>(`/requests/${requestId}/deny`, {});
  }

  createRequest(requestData: Partial<Request>): Observable<{ message: string }> {
    return this.api.post<{ message: string }>('/requests', requestData);
  }
}