import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { User } from '../models/user.model';

describe('AuthService', () => {
  let service: AuthService;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);
    TestBed.configureTestingModule({
      providers: [
        AuthService,
        { provide: Router, useValue: routerSpy }
      ]
    });
    service = TestBed.inject(AuthService);
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('login', () => {
    it('should authenticate valid credentials', (done) => {
      service.login('student@example.com', 'student123').subscribe({
        next: (response) => {
          expect(response.user.email).toBe('student@example.com');
          expect(response.user.role).toBe('student');
          expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);
          done();
        }
      });
    });

    it('should reject invalid credentials', (done) => {
      service.login('wrong@email.com', 'wrongpass').subscribe({
        error: (error) => {
          expect(error.message).toBe('Invalid credentials');
          done();
        }
      });
    });
  });

  describe('logout', () => {
    it('should clear user data and redirect to login', () => {
      service.logout();
      expect(localStorage.getItem('user')).toBeNull();
      expect(router.navigate).toHaveBeenCalledWith(['/login']);
    });
  });

  describe('isAuthenticated', () => {
    it('should return true when user is logged in', () => {
      service.login('student@example.com', 'student123').subscribe();
      expect(service.isAuthenticated()).toBeTrue();
    });

    it('should return false when user is not logged in', () => {
      service.logout();
      expect(service.isAuthenticated()).toBeFalse();
    });
  });

  describe('hasRole', () => {
    beforeEach(() => {
      service.login('student@example.com', 'student123').subscribe();
    });

    it('should return true for matching role', () => {
      expect(service.hasRole('student')).toBeTrue();
    });

    it('should return false for non-matching role', () => {
      expect(service.hasRole('instructor')).toBeFalse();
    });
  });
});