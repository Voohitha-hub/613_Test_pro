export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'instructor' | 'admin';
}

export interface Course {
  id: string;
  name: string;
  description: string;
  duration: string;
  instructorId: string;
  instructorName: string;
  enrolledStudents: number;
  content: {
    chapters: Chapter[];
  };
}

export interface Chapter {
  id: string;
  title: string;
  order: number;
  lecture: Lecture;
  slides?: Slides;
  quiz?: Quiz;
}

export interface Lecture {
  id: string;
  title: string;
  videoUrl: string;
  description: string;
}

export interface Slides {
  id: string;
  title: string;
  fileUrl: string;
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswers: string[];
  selectedAnswers?: string[];
  explanation?: string;
}

export interface PracticeTest {
  id: string;
  courseId: string;
  title: string;
  description: string;
  duration: number;
  questions: Question[];
  createdAt: string;
  attempts?: TestAttempt[];
}

export interface TestAttempt {
  id: string;
  userId: string;
  userName: string;
  startTime: string;
  endTime?: string;
  score?: number;
  answers: {
    questionId: string;
    selectedAnswers: string[];
  }[];
}

export interface Announcement {
  id: string;
  courseId: string;
  title: string;
  content: string;
  date: string;
  createdBy: string;
}

export interface Request {
  id: string;
  type: 'student_registration' | 'instructor_account';
  status: 'pending' | 'approved' | 'denied';
  date: string;
  user_data: {
    name: string;
    email: string;
    role: string;
    courseId?: string;
    courseName?: string;
  };
}