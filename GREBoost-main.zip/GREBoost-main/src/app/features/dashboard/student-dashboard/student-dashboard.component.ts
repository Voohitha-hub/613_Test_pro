import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Course } from '../../../core/models/user.model';
import { CourseService } from '../../../core/services/course.service';

@Component({
  selector: 'app-student-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="space-y-6">
      <h1 class="text-3xl font-bold text-gray-900">My Courses</h1>
      
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let course of enrolledCourses" class="card">
          <h3 class="text-xl font-semibold mb-2">{{ course.name }}</h3>
          <p class="text-gray-600 mb-4">{{ course.description }}</p>
          <div class="flex justify-between items-center">
            <span class="text-sm text-gray-500">Duration: {{ course.duration }}</span>
            <button [routerLink]="['/courses', course.id]" class="btn-primary">
              Continue Learning
            </button>
          </div>
        </div>
      </div>

      <h2 class="text-2xl font-bold text-gray-900 mt-8">Available Courses</h2>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let course of availableCourses" class="card">
          <h3 class="text-xl font-semibold mb-2">{{ course.name }}</h3>
          <p class="text-gray-600 mb-4">{{ course.description }}</p>
          <div class="flex justify-between items-center">
            <span class="text-sm text-gray-500">Instructor: {{ course.instructorName }}</span>
            <button (click)="enrollCourse(course.id)" class="btn-primary">
              Enroll Now
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class StudentDashboardComponent implements OnInit {
  enrolledCourses: Course[] = [];
  availableCourses: Course[] = [];

  constructor(private courseService: CourseService) {}

  ngOnInit(): void {
    this.courseService.getEnrolledCourses().subscribe(courses => {
      this.enrolledCourses = courses;
    });

    this.courseService.getAvailableCourses().subscribe(courses => {
      this.availableCourses = courses;
    });
  }

  enrollCourse(courseId: string): void {
    this.courseService.enrollInCourse(courseId).subscribe(() => {
      // Refresh the course lists after enrollment
      this.ngOnInit();
    });
  }
}