import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { StudentDashboardComponent } from './student-dashboard/student-dashboard.component';
import { InstructorDashboardComponent } from './instructor-dashboard/instructor-dashboard.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    StudentDashboardComponent,
    InstructorDashboardComponent,
    AdminDashboardComponent
  ],
  template: `
    <div class="container mx-auto px-4 py-8">
      <ng-container [ngSwitch]="userRole">
        <app-student-dashboard *ngSwitchCase="'student'"></app-student-dashboard>
        <app-instructor-dashboard *ngSwitchCase="'instructor'"></app-instructor-dashboard>
        <app-admin-dashboard *ngSwitchCase="'admin'"></app-admin-dashboard>
      </ng-container>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  userRole: string = '';

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    this.userRole = this.authService.getCurrentUserValue()?.role || '';
  }
}