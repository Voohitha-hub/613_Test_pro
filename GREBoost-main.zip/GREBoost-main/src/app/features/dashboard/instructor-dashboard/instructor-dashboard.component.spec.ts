import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { InstructorDashboardComponent } from './instructor-dashboard.component';
import { CourseService } from '../../../core/services/course.service';
import { Course } from '../../../core/models/user.model';
import { of } from 'rxjs';

describe('InstructorDashboardComponent', () => {
  let component: InstructorDashboardComponent;
  let fixture: ComponentFixture<InstructorDashboardComponent>;
  let courseService: jasmine.SpyObj<CourseService>;

  const mockCourse: Course = {
    id: '1',
    name: 'Test Course',
    description: 'Test Description',
    duration: '8 weeks',
    instructorId: '1',
    instructorName: 'Test Instructor',
    enrolledStudents: 10,
    content: {
      chapters: []
    }
  };

  beforeEach(async () => {
    const courseSpy = jasmine.createSpyObj('CourseService', ['getAssignedCourses']);
    courseSpy.getAssignedCourses.and.returnValue(of([mockCourse]));

    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, InstructorDashboardComponent],
      providers: [
        { provide: CourseService, useValue: courseSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(InstructorDashboardComponent);
    component = fixture.componentInstance;
    courseService = TestBed.inject(CourseService) as jasmine.SpyObj<CourseService>;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load courses on init', () => {
    expect(courseService.getAssignedCourses).toHaveBeenCalled();
    expect(component.assignedCourses).toEqual([mockCourse]);
  });

  it('should calculate total students correctly', () => {
    expect(component.getTotalStudents()).toBe(10);
  });

  it('should calculate average enrollment correctly', () => {
    expect(component.getAverageEnrollment()).toBe(10);
  });

  it('should handle zero courses for average enrollment', () => {
    component.assignedCourses = [];
    expect(component.getAverageEnrollment()).toBe(0);
  });
});