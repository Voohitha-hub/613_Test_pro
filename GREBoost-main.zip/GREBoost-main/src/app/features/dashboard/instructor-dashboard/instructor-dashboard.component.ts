import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Course } from '../../../core/models/user.model';
import { CourseService } from '../../../core/services/course.service';

@Component({
  selector: 'app-instructor-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="space-y-6">
      <!-- Stats Overview -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="card bg-blue-50">
          <h3 class="text-xl font-semibold mb-2">My Courses</h3>
          <p class="text-3xl font-bold text-blue-600">{{ assignedCourses.length }}</p>
        </div>
        <div class="card bg-green-50">
          <h3 class="text-xl font-semibold mb-2">Total Students</h3>
          <p class="text-3xl font-bold text-green-600">{{ getTotalStudents() }}</p>
        </div>
        <div class="card bg-purple-50">
          <h3 class="text-xl font-semibold mb-2">Average Enrollment</h3>
          <p class="text-3xl font-bold text-purple-600">{{ getAverageEnrollment() }}</p>
        </div>
      </div>

      <h1 class="text-3xl font-bold text-gray-900">My Courses</h1>
      
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let course of assignedCourses" class="card hover:shadow-lg transition-shadow duration-300">
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-xl font-semibold">{{ course.name }}</h3>
            <button (click)="editCourse(course)" class="text-blue-600 hover:text-blue-800">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
              </svg>
            </button>
          </div>

          <p class="text-gray-600 mb-4">{{ course.description }}</p>
          
          <div class="space-y-2 text-sm text-gray-500">
            <div class="flex justify-between">
              <span>Duration:</span>
              <span class="font-medium">{{ course.duration }}</span>
            </div>
            <div class="flex justify-between">
              <span>Enrolled Students:</span>
              <span class="font-medium">{{ course.enrolledStudents }}</span>
            </div>
          </div>

          <div class="mt-4 grid grid-cols-2 gap-2">
            <button [routerLink]="['/courses', course.id]" class="btn-primary">
              Manage Content
            </button>
            <button [routerLink]="['/courses', course.id, 'students']" class="btn-success">
              View Students
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class InstructorDashboardComponent implements OnInit {
  assignedCourses: Course[] = [];

  constructor(private courseService: CourseService) {}

  ngOnInit(): void {
    this.loadCourses();
  }

  loadCourses(): void {
    this.courseService.getAssignedCourses().subscribe(courses => {
      this.assignedCourses = courses;
    });
  }

  getTotalStudents(): number {
    return this.assignedCourses.reduce((total, course) => total + course.enrolledStudents, 0);
  }

  getAverageEnrollment(): number {
    if (this.assignedCourses.length === 0) return 0;
    return Math.round(this.getTotalStudents() / this.assignedCourses.length);
  }

  editCourse(course: Course): void {
    // Navigate to course edit page or open modal
  }
}