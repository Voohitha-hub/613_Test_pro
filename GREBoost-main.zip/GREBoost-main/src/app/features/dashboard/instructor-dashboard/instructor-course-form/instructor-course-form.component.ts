import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Course } from '../../../../core/models/user.model';

@Component({
  selector: 'app-instructor-course-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <form [formGroup]="courseForm" (ngSubmit)="onSubmit()" class="space-y-4">
      <div>
        <label for="name" class="block text-sm font-medium text-gray-700">Course Name</label>
        <input
          type="text"
          id="name"
          formControlName="name"
          class="form-input"
          [class.border-red-500]="courseForm.get('name')?.invalid && courseForm.get('name')?.touched"
        />
        <p *ngIf="courseForm.get('name')?.invalid && courseForm.get('name')?.touched" class="mt-1 text-sm text-red-500">
          Course name is required
        </p>
      </div>

      <div>
        <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          id="description"
          formControlName="description"
          rows="3"
          class="form-input"
          [class.border-red-500]="courseForm.get('description')?.invalid && courseForm.get('description')?.touched"
        ></textarea>
        <p *ngIf="courseForm.get('description')?.invalid && courseForm.get('description')?.touched" class="mt-1 text-sm text-red-500">
          Description is required
        </p>
      </div>

      <div>
        <label for="duration" class="block text-sm font-medium text-gray-700">Duration</label>
        <input
          type="text"
          id="duration"
          formControlName="duration"
          placeholder="e.g., 8 weeks"
          class="form-input"
          [class.border-red-500]="courseForm.get('duration')?.invalid && courseForm.get('duration')?.touched"
        />
        <p *ngIf="courseForm.get('duration')?.invalid && courseForm.get('duration')?.touched" class="mt-1 text-sm text-red-500">
          Duration is required
        </p>
      </div>

      <div class="flex justify-end space-x-2">
        <button type="button" (click)="onCancel()" class="btn-danger">
          Cancel
        </button>
        <button type="submit" [disabled]="courseForm.invalid" class="btn-primary">
          {{ course ? 'Update Course' : 'Create Course' }}
        </button>
      </div>
    </form>
  `
})
export class InstructorCourseFormComponent implements OnInit {
  @Input() course: Course | null = null;
  @Output() formSubmit = new EventEmitter<Partial<Course>>();
  @Output() formCancel = new EventEmitter<void>();

  courseForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.courseForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      duration: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    if (this.course) {
      this.courseForm.patchValue({
        name: this.course.name,
        description: this.course.description,
        duration: this.course.duration
      });
    }
  }

  onSubmit(): void {
    if (this.courseForm.valid) {
      this.formSubmit.emit(this.courseForm.value);
      this.courseForm.reset();
    }
  }

  onCancel(): void {
    this.formCancel.emit();
    this.courseForm.reset();
  }
}