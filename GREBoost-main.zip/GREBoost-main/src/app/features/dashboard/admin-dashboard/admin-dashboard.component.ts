import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Course, Request } from '../../../core/models/user.model';
import { CourseService } from '../../../core/services/course.service';
import { RequestService } from '../../../core/services/request.service';
import { AdminCourseFormComponent } from './admin-course-form/admin-course-form.component';
import { AdminCoursesTabComponent } from './admin-courses-tab/admin-courses-tab.component';
import { AdminRequestsTabComponent } from './admin-requests-tab/admin-requests-tab.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    AdminCourseFormComponent,
    AdminCoursesTabComponent,
    AdminRequestsTabComponent
  ],
  template: `
    <div class="space-y-6">
      <!-- Stats Overview -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="card bg-blue-50">
          <h3 class="text-xl font-semibold mb-2">Total Courses</h3>
          <p class="text-3xl font-bold text-blue-600">{{ courses.length }}</p>
        </div>
        <div class="card bg-green-50">
          <h3 class="text-xl font-semibold mb-2">Active Students</h3>
          <p class="text-3xl font-bold text-green-600">{{ getTotalStudents() }}</p>
        </div>
        <div class="card bg-purple-50">
          <h3 class="text-xl font-semibold mb-2">Pending Requests</h3>
          <p class="text-3xl font-bold text-purple-600">{{ pendingRequests.length }}</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="bg-white rounded-lg shadow-md">
        <div class="border-b border-gray-200">
          <nav class="flex space-x-8 px-6" aria-label="Tabs">
            <button
              *ngFor="let tab of tabs"
              (click)="activeTab = tab.id"
              [class.text-blue-600]="activeTab === tab.id"
              [class.border-blue-600]="activeTab === tab.id"
              class="py-4 px-1 border-b-2 font-medium text-sm"
              [class.border-transparent]="activeTab !== tab.id"
              [class.text-gray-500]="activeTab !== tab.id"
              [class.hover:text-gray-700]="activeTab !== tab.id"
              [class.hover:border-gray-300]="activeTab !== tab.id"
            >
              {{ tab.name }}
            </button>
          </nav>
        </div>

        <div class="p-6">
          <!-- Courses Tab -->
          <app-admin-courses-tab
            *ngIf="activeTab === 'courses'"
            [courses]="courses"
            [instructors]="instructors"
            (courseUpdated)="handleCourseUpdate($event)"
            (courseDeleted)="handleCourseDelete($event)"
          ></app-admin-courses-tab>

          <!-- Requests Tab -->
          <app-admin-requests-tab
            *ngIf="activeTab === 'requests'"
            [requests]="pendingRequests"
            (requestApproved)="handleRequestApprove($event)"
            (requestDenied)="handleRequestDeny($event)"
          ></app-admin-requests-tab>
        </div>
      </div>
    </div>
  `
})
export class AdminDashboardComponent implements OnInit {
  activeTab: string = 'courses';
  courses: Course[] = [];
  pendingRequests: Request[] = [];
  
  tabs = [
    { id: 'courses', name: 'Courses' },
    { id: 'requests', name: 'Requests' }
  ];

  instructors = [
    { id: '1', name: 'John Smith' },
    { id: '2', name: 'Jane Doe' },
    { id: '3', name: 'Robert Johnson' }
  ];

  constructor(
    private courseService: CourseService,
    private requestService: RequestService
  ) {}

  ngOnInit(): void {
    this.loadCourses();
    this.loadRequests();
  }

  loadCourses(): void {
    this.courseService.getAllCourses().subscribe(courses => {
      this.courses = courses;
    });
  }

  loadRequests(): void {
    this.requestService.getPendingRequests().subscribe(requests => {
      this.pendingRequests = requests;
    });
  }

  getTotalStudents(): number {
    return this.courses.reduce((total, course) => total + course.enrolledStudents, 0);
  }

  handleCourseUpdate(course: Course): void {
    this.loadCourses();
  }

  handleCourseDelete(courseId: string): void {
    this.loadCourses();
  }

  handleRequestApprove(requestId: string): void {
    this.requestService.approveRequest(requestId).subscribe(() => {
      this.loadRequests();
    });
  }

  handleRequestDeny(requestId: string): void {
    this.requestService.denyRequest(requestId).subscribe(() => {
      this.loadRequests();
    });
  }
}