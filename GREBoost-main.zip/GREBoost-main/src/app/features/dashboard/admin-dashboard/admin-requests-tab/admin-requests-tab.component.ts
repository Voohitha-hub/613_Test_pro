import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Request } from '../../../../core/models/user.model';
import { RequestService } from '../../../../core/services/request.service';

@Component({
  selector: 'app-admin-requests-tab',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <h2 class="text-2xl font-bold text-gray-900">Pending Requests</h2>

      <div class="space-y-4">
        <div *ngFor="let request of requests" class="card">
          <div class="flex justify-between items-start">
            <div>
              <div class="flex items-center space-x-2">
                <h3 class="text-lg font-semibold">{{ request.user_data.name }}</h3>
                <span class="px-2 py-1 text-xs rounded-full"
                  [class.bg-blue-100]="request.type === 'student_registration'"
                  [class.text-blue-800]="request.type === 'student_registration'"
                  [class.bg-purple-100]="request.type === 'instructor_account'"
                  [class.text-purple-800]="request.type === 'instructor_account'"
                >
                  {{ request.type === 'student_registration' ? 'Student Registration' : 'Instructor Application' }}
                </span>
              </div>
              <p class="text-gray-600">{{ request.user_data.email }}</p>
              <p class="text-sm text-gray-500">Submitted on {{ request.date }}</p>
              
              <div *ngIf="request.type === 'student_registration' && request.user_data.courseName" class="mt-2">
                <p class="text-sm text-gray-600">
                  Requesting enrollment in: <span class="font-medium">{{ request.user_data.courseName }}</span>
                </p>
              </div>
            </div>

            <div class="flex space-x-2">
              <button 
                (click)="onApprove(request.id)"
                class="btn-success"
                [disabled]="isProcessing"
              >
                {{ isProcessing ? 'Processing...' : 'Approve' }}
              </button>
              <button 
                (click)="onDeny(request.id)"
                class="btn-danger"
                [disabled]="isProcessing"
              >
                {{ isProcessing ? 'Processing...' : 'Deny' }}
              </button>
            </div>
          </div>
        </div>

        <div *ngIf="requests.length === 0" class="text-center py-8 text-gray-500">
          No pending requests at this time.
        </div>
      </div>

      <!-- Error Alert -->
      <div *ngIf="errorMessage" 
           class="fixed bottom-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded"
           role="alert">
        <span class="block sm:inline">{{ errorMessage }}</span>
        <button 
          (click)="errorMessage = ''"
          class="absolute top-0 bottom-0 right-0 px-4 py-3"
        >
          <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      </div>
    </div>
  `
})
export class AdminRequestsTabComponent {
  @Input() requests: Request[] = [];
  @Output() requestApproved = new EventEmitter<string>();
  @Output() requestDenied = new EventEmitter<string>();

  isProcessing = false;
  errorMessage = '';

  constructor(private requestService: RequestService) {}

  onApprove(requestId: string): void {
    this.isProcessing = true;
    this.requestService.approveRequest(requestId).subscribe({
      next: () => {
        this.requestApproved.emit(requestId);
        this.isProcessing = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to approve request. Please try again.';
        this.isProcessing = false;
        console.error('Error approving request:', error);
      }
    });
  }

  onDeny(requestId: string): void {
    this.isProcessing = true;
    this.requestService.denyRequest(requestId).subscribe({
      next: () => {
        this.requestDenied.emit(requestId);
        this.isProcessing = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to deny request. Please try again.';
        this.isProcessing = false;
        console.error('Error denying request:', error);
      }
    });
  }
}