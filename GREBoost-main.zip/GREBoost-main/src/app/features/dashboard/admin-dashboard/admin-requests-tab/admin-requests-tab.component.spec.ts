import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminRequestsTabComponent } from './admin-requests-tab.component';
import { Request } from '../../../../core/models/user.model';

describe('AdminRequestsTabComponent', () => {
  let component: AdminRequestsTabComponent;
  let fixture: ComponentFixture<AdminRequestsTabComponent>;

  const mockRequests: Request[] = [
    {
      id: '1',
      type: 'instructor_account',
      status: 'pending',
      date: '2024-02-20',
      user_data: {
        name: 'Test User',
        email: 'test@example.com',
        role: 'instructor'
      }
    },
    {
      id: '2',
      type: 'student_registration',
      status: 'pending',
      date: '2024-02-20',
      user_data: {
        name: 'Test Student',
        email: 'student@example.com',
        role: 'student',
        courseId: '1',
        courseName: 'Test Course'
      }
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminRequestsTabComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AdminRequestsTabComponent);
    component = fixture.componentInstance;
    component.requests = mockRequests;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});