import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminRequestsTabComponent } from './admin-requests-tab/admin-requests-tab.component';
import { RequestService } from '../../../core/services/request.service';
import { Course, Request } from '../../../core/models/user.model';
import { of, throwError } from 'rxjs';

describe('AdminRequestsTabComponent', () => {
  let component: AdminRequestsTabComponent;
  let fixture: ComponentFixture<AdminRequestsTabComponent>;
  let requestService: jasmine.SpyObj<RequestService>;

  const mockRequests: Request[] = [
    {
      id: '1',
      type: 'instructor_account',
      status: 'pending',
      date: '2024-02-20',
      user_data: {
        name: 'Test User',
        email: 'test@example.com',
        role: 'instructor'
      }
    }
  ];

  beforeEach(async () => {
    const requestSpy = jasmine.createSpyObj('RequestService', ['approveRequest', 'denyRequest']);
    requestSpy.approveRequest.and.returnValue(of(void 0));
    requestSpy.denyRequest.and.returnValue(of(void 0));

    await TestBed.configureTestingModule({
      imports: [AdminRequestsTabComponent],
      providers: [
        { provide: RequestService, useValue: requestSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AdminRequestsTabComponent);
    component = fixture.componentInstance;
    requestService = TestBed.inject(RequestService) as jasmine.SpyObj<RequestService>;
    component.requests = mockRequests;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle request approval', () => {
    spyOn(component.requestApproved, 'emit');
    component.onApprove('1');
    expect(requestService.approveRequest).toHaveBeenCalledWith('1');
    expect(component.requestApproved.emit).toHaveBeenCalledWith('1');
    expect(component.isProcessing).toBeFalse();
  });

  it('should handle request denial', () => {
    spyOn(component.requestDenied, 'emit');
    component.onDeny('1');
    expect(requestService.denyRequest).toHaveBeenCalledWith('1');
    expect(component.requestDenied.emit).toHaveBeenCalledWith('1');
    expect(component.isProcessing).toBeFalse();
  });

  it('should handle approval error', () => {
    requestService.approveRequest.and.returnValue(throwError(() => new Error('Test error')));
    component.onApprove('1');
    expect(component.errorMessage).toBe('Failed to approve request. Please try again.');
    expect(component.isProcessing).toBeFalse();
  });

  it('should handle denial error', () => {
    requestService.denyRequest.and.returnValue(throwError(() => new Error('Test error')));
    component.onDeny('1');
    expect(component.errorMessage).toBe('Failed to deny request. Please try again.');
    expect(component.isProcessing).toBeFalse();
  });
});