import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Course } from '../../../../core/models/user.model';

@Component({
  selector: 'app-admin-course-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <form [formGroup]="courseForm" (ngSubmit)="onSubmit()" class="space-y-4">
      <div>
        <label for="name" class="block text-sm font-medium text-gray-700">Course Name</label>
        <input
          type="text"
          id="name"
          formControlName="name"
          class="form-input"
          [class.border-red-500]="courseForm.get('name')?.invalid && courseForm.get('name')?.touched"
        />
        <p *ngIf="courseForm.get('name')?.invalid && courseForm.get('name')?.touched" class="mt-1 text-sm text-red-500">
          Course name is required
        </p>
      </div>

      <div>
        <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
        <textarea
          id="description"
          formControlName="description"
          rows="3"
          class="form-input"
          [class.border-red-500]="courseForm.get('description')?.invalid && courseForm.get('description')?.touched"
        ></textarea>
        <p *ngIf="courseForm.get('description')?.invalid && courseForm.get('description')?.touched" class="mt-1 text-sm text-red-500">
          Description is required
        </p>
      </div>

      <div>
        <label for="duration" class="block text-sm font-medium text-gray-700">Duration</label>
        <input
          type="text"
          id="duration"
          formControlName="duration"
          class="form-input"
          [class.border-red-500]="courseForm.get('duration')?.invalid && courseForm.get('duration')?.touched"
        />
        <p *ngIf="courseForm.get('duration')?.invalid && courseForm.get('duration')?.touched" class="mt-1 text-sm text-red-500">
          Duration is required
        </p>
      </div>

      <div>
        <label for="instructorId" class="block text-sm font-medium text-gray-700">Instructor</label>
        <select
          id="instructorId"
          formControlName="instructorId"
          class="form-input"
          [class.border-red-500]="courseForm.get('instructorId')?.invalid && courseForm.get('instructorId')?.touched"
        >
          <option value="">Select an instructor</option>
          <option *ngFor="let instructor of instructors" [value]="instructor.id">
            {{ instructor.name }}
          </option>
        </select>
        <p *ngIf="courseForm.get('instructorId')?.invalid && courseForm.get('instructorId')?.touched" class="mt-1 text-sm text-red-500">
          Instructor is required
        </p>
      </div>

      <div class="flex justify-end space-x-2">
        <button type="button" (click)="onCancel()" class="btn-danger">
          Cancel
        </button>
        <button type="submit" [disabled]="courseForm.invalid" class="btn-primary">
          {{ course ? 'Update Course' : 'Create Course' }}
        </button>
      </div>
    </form>
  `
})
export class AdminCourseFormComponent implements OnInit {
  @Input() course: Course | null = null;
  @Input() instructors: { id: string; name: string; }[] = [];
  @Output() formSubmit = new EventEmitter<Partial<Course>>();
  @Output() formCancel = new EventEmitter<void>();

  courseForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.courseForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      duration: ['', Validators.required],
      instructorId: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    if (this.course) {
      this.courseForm.patchValue({
        name: this.course.name,
        description: this.course.description,
        duration: this.course.duration,
        instructorId: this.course.instructorId
      });
    }
  }

  onSubmit(): void {
    if (this.courseForm.valid) {
      const formValue = this.courseForm.value;
      const instructor = this.instructors.find(i => i.id === formValue.instructorId);
      
      const courseData: Partial<Course> = {
        ...formValue,
        instructorName: instructor?.name || ''
      };

      this.formSubmit.emit(courseData);
      this.courseForm.reset();
    }
  }

  onCancel(): void {
    this.formCancel.emit();
    this.courseForm.reset();
  }
}