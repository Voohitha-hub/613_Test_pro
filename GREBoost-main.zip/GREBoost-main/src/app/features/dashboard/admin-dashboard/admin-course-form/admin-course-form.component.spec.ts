import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { AdminCourseFormComponent } from './admin-course-form.component';
import { Course } from '../../../../core/models/user.model';

describe('AdminCourseFormComponent', () => {
  let component: AdminCourseFormComponent;
  let fixture: ComponentFixture<AdminCourseFormComponent>;

  const mockCourse: Course = {
    id: '1',
    name: 'Test Course',
    description: 'Test Description',
    duration: '8 weeks',
    instructorId: '1',
    instructorName: 'Test Instructor',
    enrolledStudents: 0,
    content: {
      chapters: []
    }
  };

  const mockInstructors = [
    { id: '1', name: 'Test Instructor' },
    { id: '2', name: 'Another Instructor' }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, AdminCourseFormComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AdminCourseFormComponent);
    component = fixture.componentInstance;
    component.instructors = mockInstructors;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('form initialization', () => {
    it('should initialize with empty form', () => {
      expect(component.courseForm.get('name')?.value).toBe('');
      expect(component.courseForm.get('description')?.value).toBe('');
      expect(component.courseForm.get('duration')?.value).toBe('');
      expect(component.courseForm.get('instructorId')?.value).toBe('');
    });

    it('should populate form with course data when provided', () => {
      component.course = mockCourse;
      component.ngOnInit();
      expect(component.courseForm.get('name')?.value).toBe(mockCourse.name);
      expect(component.courseForm.get('description')?.value).toBe(mockCourse.description);
      expect(component.courseForm.get('duration')?.value).toBe(mockCourse.duration);
      expect(component.courseForm.get('instructorId')?.value).toBe(mockCourse.instructorId);
    });
  });
});