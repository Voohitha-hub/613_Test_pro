import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AdminCoursesTabComponent } from './admin-courses-tab.component';
import { CourseService } from '../../../../core/services/course.service';
import { Course } from '../../../../core/models/user.model';
import { of } from 'rxjs';

describe('AdminCoursesTabComponent', () => {
  let component: AdminCoursesTabComponent;
  let fixture: ComponentFixture<AdminCoursesTabComponent>;
  let courseService: jasmine.SpyObj<CourseService>;

  const mockCourse: Course = {
    id: '1',
    name: 'Test Course',
    description: 'Test Description',
    duration: '8 weeks',
    instructorId: '1',
    instructorName: 'Test Instructor',
    enrolledStudents: 10,
    content: {
      chapters: []
    }
  };

  beforeEach(async () => {
    const courseSpy = jasmine.createSpyObj('CourseService', 
      ['updateCourse', 'createCourse', 'deleteCourse']);
    courseSpy.updateCourse.and.returnValue(of(mockCourse));
    courseSpy.createCourse.and.returnValue(of(mockCourse));
    courseSpy.deleteCourse.and.returnValue(of(void 0));

    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, AdminCoursesTabComponent],
      providers: [
        { provide: CourseService, useValue: courseSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AdminCoursesTabComponent);
    component = fixture.componentInstance;
    courseService = TestBed.inject(CourseService) as jasmine.SpyObj<CourseService>;
    component.courses = [mockCourse];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('course management', () => {
    it('should handle course creation', () => {
      spyOn(component.courseUpdated, 'emit');
      const courseData = {
        name: 'New Course',
        description: 'New Description',
        duration: '4 weeks',
        instructorId: '1'
      };

      component.handleCourseSubmit(courseData);
      expect(courseService.createCourse).toHaveBeenCalledWith(courseData);
      expect(component.courseUpdated.emit).toHaveBeenCalledWith(mockCourse);
    });

    it('should handle course update', () => {
      spyOn(component.courseUpdated, 'emit');
      component.editingCourse = mockCourse;
      const updateData = { ...mockCourse, name: 'Updated Course' };

      component.handleCourseSubmit(updateData);
      expect(courseService.updateCourse).toHaveBeenCalledWith(mockCourse.id, updateData);
      expect(component.courseUpdated.emit).toHaveBeenCalledWith(mockCourse);
    });
  });
});