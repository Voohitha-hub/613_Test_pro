import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  template: `
    <div class="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 py-12 px-4 sm:px-6 lg:px-8">
      <div class="max-w-md w-full space-y-8 bg-white p-8 rounded-xl shadow-lg">
        <div class="text-center">
          <!-- Logo -->
          <div class="flex justify-center">
            <div class="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center text-white text-2xl font-bold">
              GRE
            </div>
          </div>
          <h2 class="mt-6 text-3xl font-extrabold text-gray-900">
            Create your account
          </h2>
          <p class="mt-2 text-sm text-gray-600">
            Join GREBoost and start your preparation journey
          </p>
        </div>

        <form class="mt-8 space-y-6" [formGroup]="signupForm" (ngSubmit)="onSubmit()">
          <div class="rounded-md -space-y-px">
            <div class="mb-4">
              <label for="name" class="block text-sm font-medium text-gray-700">Full Name</label>
              <input
                type="text"
                id="name"
                formControlName="name"
                class="form-input rounded-t-md"
                placeholder="John Doe"
                required
              />
              <p *ngIf="signupForm.get('name')?.invalid && signupForm.get('name')?.touched" 
                 class="mt-1 text-sm text-red-600">
                Full name is required
              </p>
            </div>

            <div class="mb-4">
              <label for="email" class="block text-sm font-medium text-gray-700">Email address</label>
              <input
                type="email"
                id="email"
                formControlName="email"
                class="form-input"
                placeholder="you@example.com"
                required
              />
              <p *ngIf="signupForm.get('email')?.invalid && signupForm.get('email')?.touched" 
                 class="mt-1 text-sm text-red-600">
                Valid email is required
              </p>
            </div>

            <div class="mb-4">
              <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
              <input
                type="password"
                id="password"
                formControlName="password"
                class="form-input"
                placeholder="••••••••"
                required
              />
              <p *ngIf="signupForm.get('password')?.invalid && signupForm.get('password')?.touched" 
                 class="mt-1 text-sm text-red-600">
                Password must be at least 6 characters
              </p>
            </div>

            <div class="mb-4">
              <label for="role" class="block text-sm font-medium text-gray-700">I want to join as</label>
              <select 
                id="role"
                formControlName="role"
                class="form-input rounded-b-md"
                required
              >
                <option value="">Select role</option>
                <option value="student">Student</option>
                <option value="instructor">Instructor</option>
              </select>
              <p *ngIf="signupForm.get('role')?.invalid && signupForm.get('role')?.touched" 
                 class="mt-1 text-sm text-red-600">
                Please select a role
              </p>
            </div>
          </div>

          <div>
            <button
              type="submit"
              [disabled]="signupForm.invalid || isSubmitting"
              class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <span *ngIf="isSubmitting" class="absolute left-0 inset-y-0 flex items-center pl-3">
                <!-- Loading spinner -->
                <svg class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </span>
              {{ isSubmitting ? 'Creating account...' : 'Sign up' }}
            </button>
          </div>

          <!-- Error Message -->
          <div *ngIf="errorMessage" class="text-center text-sm text-red-600">
            {{ errorMessage }}
          </div>

          <!-- Success Message -->
          <div *ngIf="successMessage" class="text-center text-sm text-green-600">
            {{ successMessage }}
          </div>

          <!-- Sign In Link -->
          <div class="text-center mt-4">
            <p class="text-sm text-gray-600">Already have an account?</p>
            <a 
              routerLink="/login" 
              class="text-indigo-600 hover:text-indigo-500 font-medium"
            >
              Sign in here
            </a>
          </div>
        </form>
      </div>
    </div>
  `
})
export class SignupComponent {
  signupForm: FormGroup;
  isSubmitting = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.signupForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.signupForm.valid) {
      this.isSubmitting = true;
      this.errorMessage = '';
      this.successMessage = '';

      const formData = this.signupForm.value;

      if (formData.role === 'instructor') {
        // For instructors, create a pending request
        this.authService.createInstructorRequest(formData).subscribe({
          next: () => {
            this.isSubmitting = false;
            this.successMessage = 'Your instructor application has been submitted for review. We will notify you once it\'s approved.';
            setTimeout(() => this.router.navigate(['/login']), 3000);
          },
          error: (error) => {
            this.isSubmitting = false;
            this.errorMessage = 'Failed to submit instructor application. Please try again.';
            console.error('Signup error:', error);
          }
        });
      } else {
        // For students, direct signup
        this.authService.signup(formData).subscribe({
          next: () => {
            this.isSubmitting = false;
            this.successMessage = 'Account created successfully! Redirecting to login...';
            setTimeout(() => this.router.navigate(['/login']), 2000);
          },
          error: (error) => {
            this.isSubmitting = false;
            this.errorMessage = 'Failed to create account. Please try again.';
            console.error('Signup error:', error);
          }
        });
      }
    }
  }
}