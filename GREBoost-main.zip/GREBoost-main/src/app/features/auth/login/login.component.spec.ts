import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login.component';
import { AuthService } from '../../../core/services/auth.service';
import { of, throwError } from 'rxjs';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authService: jasmine.SpyObj<AuthService>;

  beforeEach(async () => {
    const authSpy = jasmine.createSpyObj('AuthService', ['login']);
    authSpy.login.and.returnValue(of({ id: '1', email: 'test@example.com' }));

    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, ReactiveFormsModule, LoginComponent],
      providers: [
        { provide: AuthService, useValue: authSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('form validation', () => {
    it('should be invalid when empty', () => {
      expect(component.loginForm.valid).toBeFalsy();
    });

    it('should validate email format', () => {
      const email = component.loginForm.controls['email'];
      email.setValue('invalid-email');
      expect(email.valid).toBeFalsy();

      email.setValue('valid@email.com');
      expect(email.valid).toBeTruthy();
    });

    it('should require password', () => {
      const password = component.loginForm.controls['password'];
      expect(password.valid).toBeFalsy();
      expect(password.errors?.['required']).toBeTruthy();
    });
  });

  describe('onLogin', () => {
    it('should call auth service on valid form submission', () => {
      component.loginForm.setValue({
        email: 'test@example.com',
        password: 'password123'
      });
      component.onLogin();
      expect(authService.login).toHaveBeenCalledWith('test@example.com', 'password123');
    });

    it('should handle login error', () => {
      authService.login.and.returnValue(throwError(() => new Error('Invalid credentials')));
      component.loginForm.setValue({
        email: 'test@example.com',
        password: 'wrongpass'
      });
      component.onLogin();
      expect(component.errorMessage).toBe('Invalid credentials. Please try again.');
    });

    it('should not call auth service if form is invalid', () => {
      component.onLogin();
      expect(authService.login).not.toHaveBeenCalled();
    });
  });
});