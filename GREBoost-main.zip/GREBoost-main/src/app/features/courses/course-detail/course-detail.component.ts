import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Course } from '../../../core/models/user.model';
import { CourseService } from '../../../core/services/course.service';
import { AuthService } from '../../../core/services/auth.service';
import { FlashcardsSectionComponent } from '../components/flashcards-section/flashcards-section.component';
import { PracticeTestsSectionComponent } from '../components/practice-tests-section/practice-tests-section.component';
import { AnnouncementsSectionComponent } from '../components/announcements-section/announcements-section.component';
import { CourseContentComponent } from '../components/course-content/course-content.component';
import { Subscription } from 'rxjs';
import { trigger, transition, style, animate } from '@angular/animations';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FlashcardsSectionComponent,
    PracticeTestsSectionComponent,
    AnnouncementsSectionComponent,
    CourseContentComponent
  ],
  animations: [
    trigger('tabAnimation', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(10px)' }),
        animate('200ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ opacity: 0, transform: 'translateY(10px)' }))
      ])
    ])
  ],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div *ngIf="course" class="space-y-6">
        <!-- Course Header -->
        <div>
          <h1 class="text-3xl font-bold text-gray-900 dark:text-white">{{ course.name }}</h1>
          <p class="mt-2 text-gray-600 dark:text-gray-300">{{ course.description }}</p>
          <div class="mt-2 text-sm text-gray-500 dark:text-gray-400">
            <p>Duration: {{ course.duration }}</p>
            <p>Instructor: {{ course.instructorName }}</p>
          </div>
        </div>

        <!-- Tabs Navigation -->
        <div class="border-b border-gray-200 dark:border-gray-700">
          <nav class="flex space-x-8" aria-label="Tabs">
            <button
              *ngFor="let tab of tabs"
              (click)="activeTab = tab.id"
              [class.text-blue-600]="activeTab === tab.id"
              [class.border-blue-600]="activeTab === tab.id"
              class="py-4 px-1 border-b-2 font-medium text-sm transition-all duration-200"
              [class.border-transparent]="activeTab !== tab.id"
              [class.text-gray-500]="activeTab !== tab.id"
              [class.hover:text-gray-700]="activeTab !== tab.id"
              [class.hover:border-gray-300]="activeTab !== tab.id"
            >
              {{ tab.name }}
            </button>
          </nav>
        </div>

        <!-- Content Tab -->
        <div [@tabAnimation]>
          <app-course-content
            *ngIf="activeTab === 'content'"
            [course]="course"
            [isInstructor]="isInstructor"
          ></app-course-content>

          <!-- Flashcards Tab -->
          <app-flashcards-section
            *ngIf="activeTab === 'flashcards'"
            [courseId]="course.id"
            [isInstructor]="isInstructor">
          </app-flashcards-section>

          <!-- Practice Tests Tab -->
          <app-practice-tests-section
            *ngIf="activeTab === 'tests'"
            [courseId]="course.id"
            [isInstructor]="isInstructor">
          </app-practice-tests-section>

          <!-- Announcements Tab -->
          <app-announcements-section
            *ngIf="activeTab === 'announcements'"
            [courseId]="course.id"
            [isInstructor]="isInstructor">
          </app-announcements-section>
        </div>
      </div>
    </div>
  `
})
export class CourseDetailComponent implements OnInit, OnDestroy {
  course: Course | null = null;
  isInstructor = false;
  activeTab = 'content';
  private routeSub?: Subscription;

  tabs = [
    { id: 'content', name: 'Content' },
    { id: 'flashcards', name: 'Flashcards' },
    { id: 'tests', name: 'Practice Tests' },
    { id: 'announcements', name: 'Announcements' }
  ];

  constructor(
    private route: ActivatedRoute,
    private courseService: CourseService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.isInstructor = this.authService.hasRole('instructor');
    
    this.routeSub = this.route.params.subscribe(params => {
      const courseId = params['id'];
      if (courseId) {
        this.loadCourse(courseId);
      }
    });
  }

  ngOnDestroy(): void {
    this.routeSub?.unsubscribe();
  }

  loadCourse(courseId: string): void {
    this.courseService.getCourseById(courseId).subscribe({
      next: (course) => {
        this.course = course;
      },
      error: (error) => {
        console.error('Error loading course:', error);
      }
    });
  }
}