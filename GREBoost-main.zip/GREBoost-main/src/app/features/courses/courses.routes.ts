import { Routes } from '@angular/router';
import { AuthGuard } from '../../core/guards/auth.guard';

export const COURSES_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () => import('./course-list/course-list.component')
      .then(m => m.CourseListComponent),
    canActivate: [AuthGuard]
  },
  {
    path: ':id',
    loadComponent: () => import('./course-detail/course-detail.component')
      .then(m => m.CourseDetailComponent),
    canActivate: [AuthGuard]
  },
  {
    path: ':id/students',
    loadComponent: () => import('./components/student-performance/student-performance.component')
      .then(m => m.StudentPerformanceComponent),
    canActivate: [AuthGuard],
    data: { role: 'instructor' }
  }
];