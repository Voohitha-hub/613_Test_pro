import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { CourseService } from '../../../core/services/course.service';
import { Course } from '../../../core/models/user.model';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-course-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Courses</h1>
        <button *ngIf="isInstructor || isAdmin" class="btn-primary">
          Create New Course
        </button>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let course of courses" class="card">
          <h3 class="text-xl font-semibold mb-2">{{ course.name }}</h3>
          <p class="text-gray-600 mb-4">{{ course.description }}</p>
          <div class="flex justify-between items-center">
            <span class="text-sm text-gray-500">
              Instructor: {{ course.instructorName }}
            </span>
            <button [routerLink]="['/courses', course.id]" class="btn-primary">
              {{ getActionButtonText() }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CourseListComponent implements OnInit {
  courses: Course[] = [];
  isInstructor: boolean = false;
  isAdmin: boolean = false;

  constructor(
    private courseService: CourseService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.isInstructor = this.authService.hasRole('instructor');
    this.isAdmin = this.authService.hasRole('admin');

    if (this.isAdmin) {
      this.courseService.getAllCourses().subscribe({
        next: (courses) => {
          this.courses = courses;
        },
        error: (error) => {
          console.error('Error fetching courses:', error);
        }
      });
    } else if (this.isInstructor) {
      this.courseService.getAssignedCourses().subscribe({
        next: (courses) => {
          this.courses = courses;
        },
        error: (error) => {
          console.error('Error fetching courses:', error);
        }
      });
    } else {
      this.courseService.getEnrolledCourses().subscribe({
        next: (courses) => {
          this.courses = courses;
        },
        error: (error) => {
          console.error('Error fetching courses:', error);
        }
      });
    }
  }

  getActionButtonText(): string {
    if (this.isInstructor) {
      return 'Manage Course';
    } else if (this.isAdmin) {
      return 'View Details';
    }
    return 'View Course';
  }
}