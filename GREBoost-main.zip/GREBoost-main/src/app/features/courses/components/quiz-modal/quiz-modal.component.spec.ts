import { ComponentFixture, TestBed } from '@angular/core/testing';
import { QuizModalComponent } from './quiz-modal.component';

describe('QuizModalComponent', () => {
  let component: QuizModalComponent;
  let fixture: ComponentFixture<QuizModalComponent>;

  const mockQuiz = {
    id: '1',
    title: 'Test Quiz',
    questions: [
      {
        id: 'q1',
        text: 'Test Question',
        options: ['A', 'B', 'C'],
        correctAnswers: ['A'],
        selectedAnswers: []
      }
    ]
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuizModalComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(QuizModalComponent);
    component = fixture.componentInstance;
    component.quiz = mockQuiz;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('option selection', () => {
    it('should handle single option selection', () => {
      const question = component.quiz.questions[0];
      component.selectSingleOption(question, 'A');
      expect(question.selectedAnswers).toEqual(['A']);
    });

    it('should handle option toggling for multiple answers', () => {
      const question = component.quiz.questions[0];
      component.toggleOption(question, 'A');
      expect(question.selectedAnswers).toContain('A');
      component.toggleOption(question, 'A');
      expect(question.selectedAnswers).not.toContain('A');
    });
  });

  describe('answer validation', () => {
    it('should correctly identify selected options', () => {
      const question = component.quiz.questions[0];
      question.selectedAnswers = ['A'];
      expect(component.isOptionSelected(question, 'A')).toBeTrue();
      expect(component.isOptionSelected(question, 'B')).toBeFalse();
    });

    it('should identify correct answers', () => {
      const question = component.quiz.questions[0];
      expect(component.isCorrectAnswer(question, 'A')).toBeTrue();
      expect(component.isCorrectAnswer(question, 'B')).toBeFalse();
    });

    it('should identify incorrect selections', () => {
      const question = component.quiz.questions[0];
      question.selectedAnswers = ['B'];
      expect(component.isIncorrectSelection(question, 'B')).toBeTrue();
      expect(component.isIncorrectSelection(question, 'A')).toBeFalse();
    });
  });
});