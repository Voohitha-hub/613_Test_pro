import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Quiz, Question } from '../../../../core/models/user.model';

@Component({
  selector: 'app-quiz-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
      <div class="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-xl font-bold">{{ quiz.title }}</h3>
          <button (click)="close.emit()"
                  class="text-gray-500 hover:text-gray-700">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div class="space-y-6 max-h-[60vh] overflow-y-auto p-4">
          <div *ngFor="let question of quiz.questions; let i = index" 
               class="p-4 rounded-lg"
               [class.bg-gray-50]="!viewingResults"
               [class.bg-green-50]="viewingResults && isQuestionCorrect(question)"
               [class.bg-red-50]="viewingResults && !isQuestionCorrect(question)">
            <p class="font-medium mb-4">{{ i + 1 }}. {{ question.text }}</p>
            
            <div class="space-y-2">
              <ng-container *ngIf="question.correctAnswers.length === 1; else multipleAnswers">
                <!-- Single Answer (Radio Buttons) -->
                <div *ngFor="let option of question.options" class="flex items-center">
                  <ng-container *ngIf="!isInstructor; else instructorRadioView">
                    <input type="radio"
                           [name]="'question' + i"
                           [id]="'q' + i + option"
                           [value]="option"
                           [checked]="isOptionSelected(question, option)"
                           (change)="selectSingleOption(question, option)"
                           [disabled]="viewingResults"
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                    <label [for]="'q' + i + option"
                           class="ml-2 block text-sm"
                           [class.text-green-600]="viewingResults && isCorrectAnswer(question, option)"
                           [class.text-red-600]="viewingResults && isIncorrectSelection(question, option)">
                      {{ option }}
                    </label>
                  </ng-container>
                  <ng-template #instructorRadioView>
                    <input type="radio"
                           [checked]="isCorrectAnswer(question, option)"
                           disabled
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300">
                    <label class="ml-2 block text-sm"
                           [class.text-green-600]="isCorrectAnswer(question, option)">
                      {{ option }}
                    </label>
                  </ng-template>
                </div>
              </ng-container>

              <ng-template #multipleAnswers>
                <!-- Multiple Answers (Checkboxes) -->
                <div *ngFor="let option of question.options" class="flex items-center">
                  <ng-container *ngIf="!isInstructor; else instructorCheckboxView">
                    <input type="checkbox"
                           [id]="'q' + i + option"
                           [checked]="isOptionSelected(question, option)"
                           (change)="toggleOption(question, option)"
                           [disabled]="viewingResults"
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label [for]="'q' + i + option"
                           class="ml-2 block text-sm"
                           [class.text-green-600]="viewingResults && isCorrectAnswer(question, option)"
                           [class.text-red-600]="viewingResults && isIncorrectSelection(question, option)">
                      {{ option }}
                    </label>
                  </ng-container>
                  <ng-template #instructorCheckboxView>
                    <input type="checkbox"
                           [checked]="isCorrectAnswer(question, option)"
                           disabled
                           class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                    <label class="ml-2 block text-sm"
                           [class.text-green-600]="isCorrectAnswer(question, option)">
                      {{ option }}
                    </label>
                  </ng-template>
                </div>
              </ng-template>
            </div>

            <div *ngIf="viewingResults && !isInstructor" class="mt-2 text-sm">
              <p class="font-medium" 
                 [class.text-green-600]="isQuestionCorrect(question)"
                 [class.text-red-600]="!isQuestionCorrect(question)">
                {{ isQuestionCorrect(question) ? 'Correct!' : 'Incorrect' }}
              </p>
              <p class="text-gray-600">Correct answer(s): {{ question.correctAnswers.join(', ') }}</p>
            </div>

            <div *ngIf="isInstructor" class="mt-2 text-sm">
              <p class="text-gray-600">Correct answer(s): {{ question.correctAnswers.join(', ') }}</p>
            </div>
          </div>
        </div>

        <div class="mt-6 flex justify-end space-x-2">
          <button *ngIf="!viewingResults && !isInstructor"
                  (click)="submit.emit()"
                  class="btn-primary">
            Submit Quiz
          </button>
          <button *ngIf="viewingResults || isInstructor"
                  (click)="close.emit()"
                  class="btn-primary">
            Close
          </button>
        </div>

        <div *ngIf="viewingResults && !isInstructor" class="mt-4 p-4 bg-gray-50 rounded-lg">
          <h4 class="font-semibold">Quiz Results</h4>
          <p>Score: {{ score }}%</p>
          <p>Correct Answers: {{ totalPoints }} out of {{ quiz.questions.length }}</p>
        </div>
      </div>
    </div>
  `
})
export class QuizModalComponent {
  @Input() quiz!: Quiz;
  @Input() isInstructor = false;
  @Input() viewingResults = false;
  @Input() score = 0;
  @Input() totalPoints = 0;
  @Output() close = new EventEmitter<void>();
  @Output() submit = new EventEmitter<void>();
  @Output() optionSelected = new EventEmitter<{ question: Question, option: string }>();

  isOptionSelected(question: Question, option: string): boolean {
    return question.selectedAnswers?.includes(option) || false;
  }

  isCorrectAnswer(question: Question, option: string): boolean {
    return question.correctAnswers.includes(option);
  }

  isIncorrectSelection(question: Question, option: string): boolean {
    return (
      (question.selectedAnswers || []).includes(option) &&
      !question.correctAnswers.includes(option)
    );
  }

  isQuestionCorrect(question: Question): boolean {
    if (!question.selectedAnswers || !question.correctAnswers) return false;
    return (
      question.selectedAnswers.length === question.correctAnswers.length &&
      question.selectedAnswers.every((answer) =>
        question.correctAnswers.includes(answer)
      )
    );
  }

  selectSingleOption(question: Question, option: string): void {
    this.optionSelected.emit({ question, option });
  }

  toggleOption(question: Question, option: string): void {
    this.optionSelected.emit({ question, option });
  }
}