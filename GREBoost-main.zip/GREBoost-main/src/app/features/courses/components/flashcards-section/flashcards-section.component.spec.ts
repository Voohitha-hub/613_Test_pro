import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { FlashcardsSectionComponent } from './flashcards-section.component';
import { FlashcardService } from '../../../../core/services/flashcard.service';
import { of } from 'rxjs';

describe('FlashcardsSectionComponent', () => {
  let component: FlashcardsSectionComponent;
  let fixture: ComponentFixture<FlashcardsSectionComponent>;
  let flashcardService: jasmine.SpyObj<FlashcardService>;

  const mockFlashcards = [
    { id: 1, question: 'Q1', answer: 'A1', isFlipped: false },
    { id: 2, question: 'Q2', answer: 'A2', isFlipped: false }
  ];

  beforeEach(async () => {
    const spy = jasmine.createSpyObj('FlashcardService', ['getFlashcards', 'createFlashcard', 'deleteFlashcard']);
    spy.getFlashcards.and.returnValue(of(mockFlashcards));
    spy.createFlashcard.and.returnValue(of(mockFlashcards[0]));
    spy.deleteFlashcard.and.returnValue(of(void 0));

    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FlashcardsSectionComponent],
      providers: [
        { provide: FlashcardService, useValue: spy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(FlashcardsSectionComponent);
    component = fixture.componentInstance;
    flashcardService = TestBed.inject(FlashcardService) as jasmine.SpyObj<FlashcardService>;
    component.courseId = '1';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load flashcards on init', () => {
    expect(flashcardService.getFlashcards).toHaveBeenCalledWith('1');
    expect(component.flashcards).toEqual(mockFlashcards);
  });

  describe('navigation', () => {
    it('should handle next card navigation', () => {
      component.currentIndex = 0;
      component.nextCard();
      expect(component.currentIndex).toBe(1);
    });

    it('should handle previous card navigation', () => {
      component.currentIndex = 1;
      component.previousCard();
      expect(component.currentIndex).toBe(0);
    });

    it('should not navigate past bounds', () => {
      component.currentIndex = 0;
      component.previousCard();
      expect(component.currentIndex).toBe(0);

      component.currentIndex = mockFlashcards.length - 1;
      component.nextCard();
      expect(component.currentIndex).toBe(mockFlashcards.length - 1);
    });
  });

  describe('form handling', () => {
    it('should create flashcard when form is valid', () => {
      component.flashcardForm.setValue({
        question: 'New Question',
        answer: 'New Answer'
      });

      component.onSubmit();
      expect(flashcardService.createFlashcard).toHaveBeenCalled();
    });

    it('should not create flashcard when form is invalid', () => {
      component.onSubmit();
      expect(flashcardService.createFlashcard).not.toHaveBeenCalled();
    });
  });

  describe('flashcard removal', () => {
    it('should remove flashcard when confirmed', () => {
      spyOn(window, 'confirm').and.returnValue(true);
      component.removeFlashcard(1);
      expect(flashcardService.deleteFlashcard).toHaveBeenCalledWith(1);
    });

    it('should not remove flashcard when cancelled', () => {
      spyOn(window, 'confirm').and.returnValue(false);
      component.removeFlashcard(1);
      expect(flashcardService.deleteFlashcard).not.toHaveBeenCalled();
    });
  });
});