import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { FlashcardComponent, Flashcard } from '../flashcard/flashcard.component';
import { FlashcardService } from '../../../../core/services/flashcard.service';

@Component({
  selector: 'app-flashcards-section',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FlashcardComponent],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold">Flashcards</h2>
        <button *ngIf="isInstructor" (click)="showAddForm = true" class="btn-primary">
          Add Flashcard
        </button>
      </div>
      
      <!-- Add Flashcard Form -->
      <div *ngIf="showAddForm" class="bg-gray-50 p-4 rounded-lg mb-6">
        <form [formGroup]="flashcardForm" (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label for="question" class="block text-sm font-medium text-gray-700">Question</label>
            <textarea
              id="question"
              formControlName="question"
              rows="2"
              class="form-input"
              [class.border-red-500]="flashcardForm.get('question')?.invalid && flashcardForm.get('question')?.touched"
            ></textarea>
          </div>

          <div>
            <label for="answer" class="block text-sm font-medium text-gray-700">Answer</label>
            <textarea
              id="answer"
              formControlName="answer"
              rows="2"
              class="form-input"
              [class.border-red-500]="flashcardForm.get('answer')?.invalid && flashcardForm.get('answer')?.touched"
            ></textarea>
          </div>

          <div class="flex justify-end space-x-2">
            <button type="button" (click)="showAddForm = false" class="btn-danger">
              Cancel
            </button>
            <button type="submit" [disabled]="flashcardForm.invalid" class="btn-primary">
              Add Flashcard
            </button>
          </div>
        </form>
      </div>

      <!-- Current Flashcard with Navigation -->
      <div *ngIf="flashcards.length > 0" class="space-y-6">
        <div class="text-center text-gray-600 mb-2">
          Card {{ currentIndex + 1 }} of {{ flashcards.length }}
        </div>

        <!-- Current Flashcard -->
        <div class="flex justify-center">
          <div class="w-full max-w-2xl">
            <app-flashcard 
              [card]="flashcards[currentIndex]"
              class="block"
            ></app-flashcard>
          </div>
        </div>

        <!-- Navigation Arrows -->
        <div class="flex justify-center items-center space-x-8 mt-6">
          <button 
            (click)="previousCard()"
            [disabled]="currentIndex === 0"
            class="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
            [class.opacity-50]="currentIndex === 0"
            [class.cursor-not-allowed]="currentIndex === 0"
          >
            <svg class="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <button 
            (click)="nextCard()"
            [disabled]="currentIndex === flashcards.length - 1"
            class="p-2 rounded-full hover:bg-gray-100 transition-colors duration-200"
            [class.opacity-50]="currentIndex === flashcards.length - 1"
            [class.cursor-not-allowed]="currentIndex === flashcards.length - 1"
          >
            <svg class="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        <!-- Flashcard Tiles -->
        <div class="mt-8">
          <h3 class="text-lg font-semibold mb-4">All Flashcards</h3>
          <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            <div 
              *ngFor="let card of flashcards; let i = index"
              (click)="selectCard(i)"
              class="p-4 rounded-lg border cursor-pointer transition-all duration-200"
              [class.bg-blue-50]="i === currentIndex"
              [class.border-blue-500]="i === currentIndex"
              [class.border-gray-200]="i !== currentIndex"
            >
              <p class="font-medium text-sm truncate">{{ card.question }}</p>
              <p class="text-xs text-gray-500 mt-1">Card {{ i + 1 }}</p>
              <button 
                *ngIf="isInstructor"
                (click)="removeFlashcard(card.id); $event.stopPropagation()"
                class="mt-2 text-red-600 hover:text-red-800 text-sm"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      </div>

      <div *ngIf="flashcards.length === 0" class="text-center py-8 text-gray-500">
        No flashcards available for this course.
      </div>
    </div>
  `
})
export class FlashcardsSectionComponent implements OnInit {
  @Input() isInstructor = false;
  @Input() courseId!: string;

  flashcards: Flashcard[] = [];
  currentIndex = 0;
  showAddForm = false;
  flashcardForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private flashcardService: FlashcardService
  ) {
    this.flashcardForm = this.fb.group({
      question: ['', Validators.required],
      answer: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadFlashcards();
  }

  loadFlashcards(): void {
    this.flashcardService.getFlashcards(this.courseId).subscribe({
      next: (flashcards) => {
        this.flashcards = flashcards;
      },
      error: (error) => {
        console.error('Error loading flashcards:', error);
      }
    });
  }

  nextCard(): void {
    if (this.currentIndex < this.flashcards.length - 1) {
      this.currentIndex++;
    }
  }

  previousCard(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }
  }

  selectCard(index: number): void {
    this.currentIndex = index;
  }

  onSubmit(): void {
    if (this.flashcardForm.valid) {
      const newFlashcard = {
        ...this.flashcardForm.value,
        courseId: this.courseId
      };

      this.flashcardService.createFlashcard(newFlashcard).subscribe({
        next: () => {
          this.loadFlashcards();
          this.flashcardForm.reset();
          this.showAddForm = false;
        },
        error: (error) => {
          console.error('Error creating flashcard:', error);
        }
      });
    }
  }

  removeFlashcard(id: number): void {
    if (confirm('Are you sure you want to remove this flashcard?')) {
      this.flashcardService.deleteFlashcard(id).subscribe({
        next: () => {
          this.loadFlashcards();
          if (this.currentIndex >= this.flashcards.length - 1) {
            this.currentIndex = Math.max(0, this.flashcards.length - 2);
          }
        },
        error: (error) => {
          console.error('Error deleting flashcard:', error);
        }
      });
    }
  }
}