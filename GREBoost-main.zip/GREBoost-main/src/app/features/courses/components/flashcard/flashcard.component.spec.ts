import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FlashcardComponent } from './flashcard.component';

describe('FlashcardComponent', () => {
  let component: FlashcardComponent;
  let fixture: ComponentFixture<FlashcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FlashcardComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(FlashcardComponent);
    component = fixture.componentInstance;
    component.card = {
      id: 1,
      question: 'Test Question',
      answer: 'Test Answer',
      isFlipped: false
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display question initially', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.textContent).toContain('Test Question');
    expect(compiled.textContent).toContain('Click to reveal answer');
  });

  it('should flip card when clicked', () => {
    const cardElement = fixture.nativeElement.querySelector('.flashcard');
    expect(component.isFlipped).toBeFalse();
    cardElement.click();
    expect(component.isFlipped).toBeTrue();
    expect(cardElement.classList.contains('flipped')).toBeTrue();
  });

  it('should show answer when flipped', () => {
    component.flip();
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.textContent).toContain('Test Answer');
    expect(compiled.textContent).toContain('Click to see question');
  });

  it('should toggle back when flipped twice', () => {
    component.flip();
    component.flip();
    expect(component.isFlipped).toBeFalse();
  });
});