import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface Flashcard {
  id: number;
  question: string;
  answer: string;
  isFlipped: boolean;
}

@Component({
  selector: 'app-flashcard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div 
      class="flashcard h-64 cursor-pointer"
      [class.flipped]="isFlipped"
      (click)="flip()"
    >
      <div class="flashcard-inner">
        <div class="flashcard-front">
          <div class="text-center">
            <p class="text-lg font-medium text-gray-800">{{ card.question }}</p>
            <p class="text-sm text-gray-500 mt-4">Click to reveal answer</p>
          </div>
        </div>
        <div class="flashcard-back">
          <div class="text-center">
            <p class="text-lg font-medium">{{ card.answer }}</p>
            <p class="text-sm text-gray-300 mt-4">Click to see question</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .flashcard {
      perspective: 1000px;
      transform-style: preserve-3d;
    }

    .flashcard-inner {
      position: relative;
      width: 100%;
      height: 100%;
      text-align: center;
      transition: transform 0.6s;
      transform-style: preserve-3d;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      border-radius: 0.5rem;
    }

    .flashcard.flipped .flashcard-inner {
      transform: rotateY(180deg);
    }

    .flashcard-front,
    .flashcard-back {
      position: absolute;
      width: 100%;
      height: 100%;
      backface-visibility: hidden;
      -webkit-backface-visibility: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.5rem;
      border-radius: 0.5rem;
    }

    .flashcard-front {
      background-color: #f9fafb;
    }

    .flashcard-back {
      background-color: #374151;
      transform: rotateY(180deg);
      color: white;
    }
  `]
})
export class FlashcardComponent {
  @Input() card!: Flashcard;
  isFlipped = false;

  flip(): void {
    this.isFlipped = !this.isFlipped;
  }
}