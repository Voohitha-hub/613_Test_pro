import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Announcement } from '../../../../core/models/user.model';
import { AnnouncementService } from '../../../../core/services/announcement.service';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
  selector: 'app-announcements-section',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold">Announcements</h2>
        <button *ngIf="isInstructor" (click)="showAddForm = true" class="btn-primary">
          Add Announcement
        </button>
      </div>

      <!-- Add Announcement Form -->
      <div *ngIf="showAddForm" class="bg-gray-50 p-4 rounded-lg mb-6">
        <form [formGroup]="announcementForm" (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label for="title" class="block text-sm font-medium text-gray-700">Title</label>
            <input
              type="text"
              id="title"
              formControlName="title"
              class="form-input"
            />
          </div>

          <div>
            <label for="content" class="block text-sm font-medium text-gray-700">Content</label>
            <textarea
              id="content"
              formControlName="content"
              rows="4"
              class="form-input"
            ></textarea>
          </div>

          <div class="flex justify-end space-x-2">
            <button type="button" (click)="showAddForm = false" class="btn-danger">
              Cancel
            </button>
            <button type="submit" [disabled]="announcementForm.invalid" class="btn-primary">
              Post Announcement
            </button>
          </div>
        </form>
      </div>

      <!-- Announcements List -->
      <div class="space-y-4">
        <div *ngFor="let announcement of announcements" 
             class="card hover:shadow-lg transition-shadow duration-200 cursor-pointer"
             (click)="openAnnouncementModal(announcement)">
          <div class="flex justify-between items-start">
            <div class="flex-1">
              <div class="flex justify-between items-start">
                <h3 class="text-lg font-semibold">{{ announcement.title }}</h3>
                <button 
                  *ngIf="isInstructor"
                  (click)="removeAnnouncement(announcement.id); $event.stopPropagation()"
                  class="text-red-600 hover:text-red-800 ml-4"
                >
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div class="mt-1 text-sm text-gray-500">
                Posted by {{ announcement.createdBy }} on {{ announcement.date | date }}
              </div>
              <div class="mt-2 text-gray-700 line-clamp-2">
                {{ announcement.content }}
              </div>
              <p class="text-sm text-blue-600 mt-2">Click to read more</p>
            </div>
          </div>
        </div>

        <div *ngIf="announcements.length === 0" class="text-center py-8 text-gray-500">
          No announcements yet.
        </div>
      </div>

      <!-- Announcement Modal -->
      <div *ngIf="selectedAnnouncement" 
           class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
           (click)="closeAnnouncementModal()">
        <div class="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6" 
             (click)="$event.stopPropagation()">
          <div class="flex justify-between items-start mb-4">
            <h2 class="text-2xl font-bold text-gray-900">{{ selectedAnnouncement.title }}</h2>
            <button 
              (click)="closeAnnouncementModal()"
              class="text-gray-500 hover:text-gray-700"
            >
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div class="mb-4 text-sm text-gray-500">
            Posted by {{ selectedAnnouncement.createdBy }} on {{ selectedAnnouncement.date | date:'medium' }}
          </div>
          
          <div class="prose max-w-none">
            <p class="whitespace-pre-wrap text-gray-700">{{ selectedAnnouncement.content }}</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .line-clamp-2 {
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
  `]
})
export class AnnouncementsSectionComponent implements OnInit {
  @Input() courseId!: string;
  @Input() isInstructor = false;

  announcements: Announcement[] = [];
  showAddForm = false;
  announcementForm: FormGroup;
  selectedAnnouncement: Announcement | null = null;

  constructor(
    private fb: FormBuilder,
    private announcementService: AnnouncementService,
    private authService: AuthService
  ) {
    this.announcementForm = this.fb.group({
      title: ['', Validators.required],
      content: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadAnnouncements();
  }

  loadAnnouncements(): void {
    this.announcementService.getAnnouncements(this.courseId).subscribe({
      next: (announcements) => {
        this.announcements = announcements;
      },
      error: (error) => {
        console.error('Error loading announcements:', error);
      }
    });
  }

  onSubmit(): void {
    if (this.announcementForm.valid) {
      const announcementData = {
        ...this.announcementForm.value,
        courseId: this.courseId,
        createdBy: this.authService.getCurrentUserValue()?.name || 'Unknown Instructor'
      };

      this.announcementService.createAnnouncement(announcementData).subscribe({
        next: () => {
          this.loadAnnouncements();
          this.announcementForm.reset();
          this.showAddForm = false;
        },
        error: (error) => {
          console.error('Error creating announcement:', error);
        }
      });
    }
  }

  removeAnnouncement(announcementId: string): void {
    if (confirm('Are you sure you want to remove this announcement?')) {
      this.announcementService.deleteAnnouncement(this.courseId, announcementId).subscribe({
        next: () => {
          this.loadAnnouncements();
        },
        error: (error) => {
          console.error('Error removing announcement:', error);
        }
      });
    }
  }

  openAnnouncementModal(announcement: Announcement): void {
    this.selectedAnnouncement = announcement;
    document.body.style.overflow = 'hidden';
  }

  closeAnnouncementModal(): void {
    this.selectedAnnouncement = null;
    document.body.style.overflow = 'auto';
  }
}