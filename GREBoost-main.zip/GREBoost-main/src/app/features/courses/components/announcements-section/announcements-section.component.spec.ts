import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { AnnouncementsSectionComponent } from './announcements-section.component';
import { AnnouncementService } from '../../../../core/services/announcement.service';
import { AuthService } from '../../../../core/services/auth.service';
import { of } from 'rxjs';

describe('AnnouncementsSectionComponent', () => {
  let component: AnnouncementsSectionComponent;
  let fixture: ComponentFixture<AnnouncementsSectionComponent>;
  let announcementService: jasmine.SpyObj<AnnouncementService>;
  let authService: jasmine.SpyObj<AuthService>;

  const mockAnnouncements = [
    {
      id: '1',
      courseId: '1',
      title: 'Test Announcement',
      content: 'Test Content',
      date: '2024-02-20',
      createdBy: 'Test Instructor'
    }
  ];

  beforeEach(async () => {
    const announcementSpy = jasmine.createSpyObj('AnnouncementService', 
      ['getAnnouncements', 'createAnnouncement', 'deleteAnnouncement']);
    const authSpy = jasmine.createSpyObj('AuthService', ['getCurrentUserValue']);

    announcementSpy.getAnnouncements.and.returnValue(of(mockAnnouncements));
    announcementSpy.createAnnouncement.and.returnValue(of(mockAnnouncements[0]));
    announcementSpy.deleteAnnouncement.and.returnValue(of(void 0));
    authSpy.getCurrentUserValue.and.returnValue({ name: 'Test User' });

    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, AnnouncementsSectionComponent],
      providers: [
        { provide: AnnouncementService, useValue: announcementSpy },
        { provide: AuthService, useValue: authSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AnnouncementsSectionComponent);
    component = fixture.componentInstance;
    announcementService = TestBed.inject(AnnouncementService) as jasmine.SpyObj<AnnouncementService>;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    component.courseId = '1';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load announcements on init', () => {
    expect(announcementService.getAnnouncements).toHaveBeenCalledWith('1');
    expect(component.announcements).toEqual(mockAnnouncements);
  });

  describe('form handling', () => {
    beforeEach(() => {
      component.showAddForm = true;
      fixture.detectChanges();
    });

    it('should create announcement when form is valid', () => {
      component.announcementForm.setValue({
        title: 'New Announcement',
        content: 'New Content'
      });

      component.onSubmit();
      expect(announcementService.createAnnouncement).toHaveBeenCalled();
      expect(component.showAddForm).toBeFalse();
    });

    it('should not create announcement when form is invalid', () => {
      component.onSubmit();
      expect(announcementService.createAnnouncement).not.toHaveBeenCalled();
    });
  });

  describe('announcement management', () => {
    it('should remove announcement when confirmed', () => {
      spyOn(window, 'confirm').and.returnValue(true);
      component.removeAnnouncement('1');
      expect(announcementService.deleteAnnouncement).toHaveBeenCalledWith('1', '1');
    });

    it('should not remove announcement when cancelled', () => {
      spyOn(window, 'confirm').and.returnValue(false);
      component.removeAnnouncement('1');
      expect(announcementService.deleteAnnouncement).not.toHaveBeenCalled();
    });
  });

  describe('modal handling', () => {
    it('should open announcement modal', () => {
      component.openAnnouncementModal(mockAnnouncements[0]);
      expect(component.selectedAnnouncement).toEqual(mockAnnouncements[0]);
      expect(document.body.style.overflow).toBe('hidden');
    });

    it('should close announcement modal', () => {
      component.selectedAnnouncement = mockAnnouncements[0];
      component.closeAnnouncementModal();
      expect(component.selectedAnnouncement).toBeNull();
      expect(document.body.style.overflow).toBe('auto');
    });
  });
});