import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import {
  Chapter,
  Course,
  Quiz,
  Question,
} from '../../../../core/models/user.model';
import { CourseService } from '../../../../core/services/course.service';
import { PracticeTestService } from '../../../../core/services/practice-test.service';
import { SafeUrlPipe } from '../../../../core/pipes/safe-url.pipe';
import { QuizModalComponent } from '../quiz-modal/quiz-modal.component';
import { trigger, transition, style, animate } from '@angular/animations';

@Component({
  selector: 'app-course-content',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, SafeUrlPipe, QuizModalComponent],
  animations: [
    trigger('expandCollapse', [
      transition(':enter', [
        style({ height: '0', opacity: 0 }),
        animate('200ms ease-out', style({ height: '*', opacity: 1 }))
      ]),
      transition(':leave', [
        animate('200ms ease-in', style({ height: '0', opacity: 0 }))
      ])
    ])
  ],
  template: `
    <div class="space-y-6">
      <!-- Add Chapter Button -->
      <div *ngIf="isInstructor" class="flex justify-end">
        <button (click)="showAddForm = true" class="btn-primary">
          Add Chapter
        </button>
      </div>

      <!-- Add Chapter Form -->
      <div *ngIf="showAddForm" class="bg-gray-50 p-4 rounded-lg mb-6">
        <form [formGroup]="chapterForm" (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700">Chapter Title</label>
            <input type="text" formControlName="title" class="form-input" />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">YouTube Video URL</label>
            <input type="text" formControlName="videoUrl" class="form-input" />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">Video Description</label>
            <textarea formControlName="description" rows="3" class="form-input"></textarea>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">Slides PDF</label>
            <input
              type="file"
              accept=".pdf"
              (change)="onPdfSelected($event)"
              class="form-input"
            />
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">Quiz Excel File</label>
            <input
              type="file"
              accept=".xlsx,.xls"
              (change)="onQuizFileSelected($event)"
              class="form-input"
            />
          </div>

          <div class="flex justify-end space-x-2">
            <button type="button" (click)="cancelAdd()" class="btn-danger">Cancel</button>
            <button type="submit" [disabled]="chapterForm.invalid" class="btn-primary">Add Chapter</button>
          </div>
        </form>
      </div>

      <!-- Chapters List -->
      <div class="space-y-4">
        <div *ngFor="let chapter of course.content.chapters" class="border rounded-lg overflow-hidden">
          <!-- Chapter Header -->
          <div class="bg-gray-50 p-4 flex justify-between items-center cursor-pointer"
               (click)="toggleChapter(chapter.id)">
            <div class="flex items-center space-x-2">
              <h3 class="text-lg font-semibold">{{ chapter.title }}</h3>
            </div>
            
            <div class="flex items-center space-x-2">
              <svg 
                class="w-5 h-5 transition-transform duration-200"
                [class.rotate-180]="expandedChapter === chapter.id"
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
              >
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
              </svg>
              
              <button *ngIf="isInstructor"
                      (click)="removeChapter(chapter.id); $event.stopPropagation()"
                      class="text-red-600 hover:text-red-800 ml-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          <!-- Chapter Content -->
          <div *ngIf="expandedChapter === chapter.id" [@expandCollapse] class="p-4 space-y-6">
            <!-- Video Section -->
            <div>
              <h4 class="font-medium mb-3">Lecture Video</h4>
              <div class="aspect-w-16 aspect-h-9 mb-3">
                <iframe [src]="chapter.lecture.videoUrl | safeUrl"
                        frameborder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowfullscreen
                        class="w-full h-[400px] rounded-lg">
                </iframe>
              </div>
              <p class="text-gray-600">{{ chapter.lecture.description }}</p>
            </div>

            <!-- Slides Section -->
            <div *ngIf="chapter.slides">
              <h4 class="font-medium mb-3">Lecture Slides</h4>
              <a [href]="chapter.slides.fileUrl"
                 download="slides.pdf"
                 class="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-800">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                        d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span>Download Slides</span>
              </a>
            </div>

            <!-- Quiz Section -->
            <div *ngIf="chapter.quiz">
              <h4 class="font-medium mb-3">Chapter Quiz</h4>
              <button (click)="startQuiz(chapter.quiz)"
                      class="btn-primary">
                {{ isInstructor ? 'View Quiz' : 'Start Quiz' }}
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Quiz Modal -->
      <app-quiz-modal
        *ngIf="activeQuiz"
        [quiz]="activeQuiz"
        [isInstructor]="isInstructor"
        [viewingResults]="viewingResults"
        [score]="calculateScore()"
        [totalPoints]="calculateTotalPoints()"
        (close)="closeQuiz()"
        (submit)="submitQuiz()"
        (optionSelected)="handleOptionSelection($event)">
      </app-quiz-modal>
    </div>
  `
})
export class CourseContentComponent {
  @Input() course!: Course;
  @Input() isInstructor = false;

  showAddForm = false;
  chapterForm: FormGroup;
  selectedPdfFile: File | null = null;
  selectedQuizFile: File | null = null;
  expandedChapter: string | null = null;
  activeQuiz: Quiz | null = null;
  viewingResults = false;

  constructor(
    private fb: FormBuilder,
    private courseService: CourseService,
    private practiceTestService: PracticeTestService
  ) {
    this.chapterForm = this.fb.group({
      title: ['', Validators.required],
      videoUrl: [
        '',
        [Validators.required, this.youtubeUrlValidator.bind(this)],
      ],
      description: ['', Validators.required],
    });
  }

  youtubeUrlValidator(control: any) {
    if (!control.value) return null;
    return this.courseService.validateYouTubeUrl(control.value)
      ? null
      : { invalidUrl: true };
  }

  toggleChapter(chapterId: string): void {
    this.expandedChapter =
      this.expandedChapter === chapterId ? null : chapterId;
  }

  onPdfSelected(event: any): void {
    const file = event.target.files[0];
    if (file && file.type === 'application/pdf') {
      this.selectedPdfFile = file;
    }
  }

  onQuizFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedQuizFile = file;
    }
  }

  async onSubmit(): Promise<void> {
    if (this.chapterForm.valid) {
      let slides;
      let quiz;

      if (this.selectedPdfFile) {
        const pdfData = await this.courseService.processSlidesPDF(
          this.selectedPdfFile
        );
        slides = {
          id: Math.random().toString(36).substr(2, 9),
          title: 'Lecture Slides',
          fileUrl: pdfData,
        };
      }

      if (this.selectedQuizFile) {
        const questions = await this.practiceTestService.processExcelFile(
          this.selectedQuizFile
        );
        quiz = {
          id: Math.random().toString(36).substr(2, 9),
          title: 'Chapter Quiz',
          questions,
        };
      }

      const newChapter: Chapter = {
        id: Math.random().toString(36).substr(2, 9),
        title: this.chapterForm.value.title,
        order: this.course.content.chapters.length + 1,
        lecture: {
          id: Math.random().toString(36).substr(2, 9),
          title: this.chapterForm.value.title,
          videoUrl: this.courseService.convertToEmbedUrl(
            this.chapterForm.value.videoUrl
          ),
          description: this.chapterForm.value.description,
        },
        slides,
        quiz,
      };

      this.courseService.addChapter(this.course.id, newChapter).subscribe({
        next: (updatedCourse) => {
          this.course = updatedCourse;
          this.cancelAdd();
          this.expandedChapter = newChapter.id;
        },
        error: (error) => {
          console.error('Error adding chapter:', error);
        },
      });
    }
  }

  cancelAdd(): void {
    this.showAddForm = false;
    this.chapterForm.reset();
    this.selectedPdfFile = null;
    this.selectedQuizFile = null;
  }

  removeChapter(chapterId: string): void {
    if (confirm('Are you sure you want to remove this chapter?')) {
      this.courseService.removeChapter(this.course.id, chapterId).subscribe({
        next: (updatedCourse) => {
          this.course = updatedCourse;
          if (this.expandedChapter === chapterId) {
            this.expandedChapter = null;
          }
        },
        error: (error) => {
          console.error('Error removing chapter:', error);
        },
      });
    }
  }

  startQuiz(quiz: Quiz): void {
    this.activeQuiz = {
      ...quiz,
      questions: quiz.questions.map((q) => ({ ...q, selectedAnswers: [] })),
    };
    this.viewingResults = this.isInstructor;
  }

  closeQuiz(): void {
    this.activeQuiz = null;
    this.viewingResults = false;
  }

  handleOptionSelection(event: { question: Question; option: string }): void {
    const { question, option } = event;
    if (question.correctAnswers.length === 1) {
      question.selectedAnswers = [option];
    } else {
      if (!question.selectedAnswers) {
        question.selectedAnswers = [];
      }
      const index = question.selectedAnswers.indexOf(option);
      if (index === -1) {
        question.selectedAnswers.push(option);
      } else {
        question.selectedAnswers.splice(index, 1);
      }
    }
  }

  calculateTotalPoints(): number {
    if (!this.activeQuiz) return 0;
    return this.activeQuiz.questions.reduce(
      (total, question) => total + (this.isQuestionCorrect(question) ? 1 : 0),
      0
    );
  }

  calculateScore(): number {
    if (!this.activeQuiz) return 0;
    return Math.round(
      (this.calculateTotalPoints() / this.activeQuiz.questions.length) * 100
    );
  }

  isQuestionCorrect(question: Question): boolean {
    if (!question.selectedAnswers || !question.correctAnswers) return false;
    return (
      question.selectedAnswers.length === question.correctAnswers.length &&
      question.selectedAnswers.every((answer) =>
        question.correctAnswers.includes(answer)
      )
    );
  }

  submitQuiz(): void {
    this.viewingResults = true;
  }
}