import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { CourseContentComponent } from './course-content.component';
import { CourseService } from '../../../../core/services/course.service';
import { PracticeTestService } from '../../../../core/services/practice-test.service';
import { SafeUrlPipe } from '../../../../core/pipes/safe-url.pipe';
import { of } from 'rxjs';
import { Course, Chapter } from '../../../../core/models/user.model';

describe('CourseContentComponent', () => {
  let component: CourseContentComponent;
  let fixture: ComponentFixture<CourseContentComponent>;
  let courseService: jasmine.SpyObj<CourseService>;
  let practiceTestService: jasmine.SpyObj<PracticeTestService>;

  const mockChapter: Chapter = {
    id: '1',
    title: 'Test Chapter',
    order: 1,
    lecture: {
      id: '1',
      title: 'Test Lecture',
      videoUrl: 'https://youtube.com/watch?v=123',
      description: 'Test Description'
    }
  };

  const mockCourse: Course = {
    id: '1',
    name: 'Test Course',
    description: 'Test Description',
    duration: '8 weeks',
    instructorId: '1',
    instructorName: 'Test Instructor',
    enrolledStudents: 0,
    content: {
      chapters: [mockChapter]
    }
  };

  beforeEach(async () => {
    const courseSpy = jasmine.createSpyObj('CourseService', [
      'addChapter', 
      'removeChapter', 
      'validateYouTubeUrl',
      'convertToEmbedUrl',
      'processSlidesPDF'
    ]);
    const practiceSpy = jasmine.createSpyObj('PracticeTestService', ['processExcelFile']);

    courseSpy.addChapter.and.returnValue(of(mockCourse));
    courseSpy.removeChapter.and.returnValue(of(mockCourse));
    courseSpy.validateYouTubeUrl.and.returnValue(true);
    courseSpy.convertToEmbedUrl.and.returnValue('https://youtube.com/embed/123');
    courseSpy.processSlidesPDF.and.returnValue(Promise.resolve('data:application/pdf;base64,test'));
    practiceSpy.processExcelFile.and.returnValue(Promise.resolve([]));

    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, CourseContentComponent],
      providers: [
        { provide: CourseService, useValue: courseSpy },
        { provide: PracticeTestService, useValue: practiceSpy }
      ],
      declarations: [SafeUrlPipe]
    }).compileComponents();

    fixture = TestBed.createComponent(CourseContentComponent);
    component = fixture.componentInstance;
    courseService = TestBed.inject(CourseService) as jasmine.SpyObj<CourseService>;
    practiceTestService = TestBed.inject(PracticeTestService) as jasmine.SpyObj<PracticeTestService>;
    component.course = mockCourse;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('chapter management', () => {
    it('should toggle chapter expansion', () => {
      component.toggleChapter('1');
      expect(component.expandedChapter).toBe('1');
      component.toggleChapter('1');
      expect(component.expandedChapter).toBeNull();
    });

    it('should handle PDF file selection', () => {
      const file = new File([''], 'test.pdf', { type: 'application/pdf' });
      const event = { target: { files: [file] } };
      component.onPdfSelected(event);
      expect(component.selectedPdfFile).toBe(file);
    });

    it('should handle quiz file selection', () => {
      const file = new File([''], 'test.xlsx');
      const event = { target: { files: [file] } };
      component.onQuizFileSelected(event);
      expect(component.selectedQuizFile).toBe(file);
    });

    it('should cancel add form', () => {
      component.showAddForm = true;
      component.selectedPdfFile = new File([''], 'test.pdf');
      component.selectedQuizFile = new File([''], 'test.xlsx');
      component.cancelAdd();
      expect(component.showAddForm).toBeFalse();
      expect(component.selectedPdfFile).toBeNull();
      expect(component.selectedQuizFile).toBeNull();
    });
  });

  describe('quiz handling', () => {
    const mockQuiz = {
      id: '1',
      title: 'Test Quiz',
      questions: [
        {
          id: 'q1',
          text: 'Test Question',
          options: ['A', 'B'],
          correctAnswers: ['A']
        }
      ]
    };

    it('should start quiz correctly', () => {
      component.startQuiz(mockQuiz);
      expect(component.activeQuiz).toBeTruthy();
      expect(component.activeQuiz?.questions[0].selectedAnswers).toEqual([]);
    });

    it('should handle option selection', () => {
      component.startQuiz(mockQuiz);
      component.handleOptionSelection({
        question: component.activeQuiz!.questions[0],
        option: 'A'
      });
      expect(component.activeQuiz?.questions[0].selectedAnswers).toEqual(['A']);
    });

    it('should calculate score correctly', () => {
      component.startQuiz(mockQuiz);
      component.activeQuiz!.questions[0].selectedAnswers = ['A'];
      expect(component.calculateScore()).toBe(100);
    });

    it('should close quiz', () => {
      component.startQuiz(mockQuiz);
      component.closeQuiz();
      expect(component.activeQuiz).toBeNull();
      expect(component.viewingResults).toBeFalse();
    });
  });
});