import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { NgChartsModule } from 'ng2-charts';
import { ChartConfiguration } from 'chart.js';
import { CourseService } from '../../../../core/services/course.service';
import { PracticeTestService } from '../../../../core/services/practice-test.service';
import { Course, PracticeTest, TestAttempt } from '../../../../core/models/user.model';

interface StudentPerformance {
  id: string;
  name: string;
  email: string;
  averageScore: number;
  testsTaken: number;
  performance: 'Excellent' | 'Good' | 'Average' | 'Poor' | 'Fail';
}

@Component({
  selector: 'app-student-performance',
  standalone: true,
  imports: [CommonModule, NgChartsModule, RouterModule],
  template: `
    <div class="container mx-auto px-4 py-8">
      <div class="mb-8">
        <div class="flex items-center justify-between">
          <div>
            <h2 class="text-2xl font-bold text-gray-900">Student Performance Analytics</h2>
            <p class="text-gray-600">Course: {{ course?.name }}</p>
          </div>
          <button 
            (click)="goToDashboard()" 
            class="flex items-center space-x-2 btn-primary"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>Back to Dashboard</span>
          </button>
        </div>
      </div>

      <!-- Performance Distribution Chart -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div class="bg-white p-6 rounded-lg shadow-md">
          <h3 class="text-lg font-semibold mb-4">Performance Distribution</h3>
          <canvas
            baseChart
            [data]="pieChartData"
            [options]="pieChartOptions"
            [type]="'pie'"
          >
          </canvas>
        </div>
        <div class="bg-white p-6 rounded-lg shadow-md">
          <h3 class="text-lg font-semibold mb-4">Performance Summary</h3>
          <div class="space-y-4">
            <div class="flex justify-between items-center">
              <span>Total Students</span>
              <span class="font-semibold">{{ studentPerformances.length }}</span>
            </div>
            <div class="flex justify-between items-center">
              <span>Students Attempted Tests</span>
              <span class="font-semibold">{{ getActiveStudentsCount() }}</span>
            </div>
            <div class="flex justify-between items-center">
              <span>Average Class Score</span>
              <span class="font-semibold">{{ getAverageClassScore() }}%</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Student List -->
      <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student Name
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Email
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tests Taken
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Average Score
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Performance
                </th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
              <tr *ngFor="let student of studentPerformances">
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm font-medium text-gray-900">{{ student.name }}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm text-gray-500">{{ student.email }}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm text-gray-900">{{ student.testsTaken }}</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <div class="text-sm text-gray-900">{{ student.averageScore }}%</div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                  <span class="px-2 py-1 text-xs font-semibold rounded-full"
                    [class.bg-green-100]="student.performance === 'Excellent'"
                    [class.text-green-800]="student.performance === 'Excellent'"
                    [class.bg-blue-100]="student.performance === 'Good'"
                    [class.text-blue-800]="student.performance === 'Good'"
                    [class.bg-yellow-100]="student.performance === 'Average'"
                    [class.text-yellow-800]="student.performance === 'Average'"
                    [class.bg-orange-100]="student.performance === 'Poor'"
                    [class.text-orange-800]="student.performance === 'Poor'"
                    [class.bg-red-100]="student.performance === 'Fail'"
                    [class.text-red-800]="student.performance === 'Fail'"
                  >
                    {{ student.performance }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class StudentPerformanceComponent implements OnInit {
  course: Course | null = null;
  tests: PracticeTest[] = [];
  studentPerformances: StudentPerformance[] = [];

  pieChartOptions: ChartConfiguration['options'] = {
    responsive: true,
    plugins: {
      legend: {
        position: 'right',
      }
    }
  };

  pieChartData: ChartConfiguration['data'] = {
    labels: ['Excellent', 'Good', 'Average', 'Poor', 'Fail'],
    datasets: [{
      data: [0, 0, 0, 0, 0],
      backgroundColor: [
        'rgba(34, 197, 94, 0.6)',  // green
        'rgba(59, 130, 246, 0.6)', // blue
        'rgba(234, 179, 8, 0.6)',  // yellow
        'rgba(249, 115, 22, 0.6)', // orange
        'rgba(239, 68, 68, 0.6)'   // red
      ]
    }]
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private courseService: CourseService,
    private practiceTestService: PracticeTestService
  ) {}

  ngOnInit(): void {
    const courseId = this.route.snapshot.params['id'];
    if (courseId) {
      this.loadCourseData(courseId);
    }
  }

  goToDashboard(): void {
    this.router.navigate(['/dashboard']);
  }

  private loadCourseData(courseId: string): void {
    this.courseService.getCourseById(courseId).subscribe(course => {
      this.course = course;
      this.practiceTestService.getTests(courseId).subscribe(tests => {
        this.tests = tests;
        this.calculateStudentPerformances();
        this.updateChartData();
      });
    });
  }

  private calculateStudentPerformances(): void {
    const studentMap = new Map<string, {
      name: string;
      email: string;
      scores: number[];
    }>();

    this.tests.forEach(test => {
      test.attempts?.forEach(attempt => {
        if (!studentMap.has(attempt.userId)) {
          studentMap.set(attempt.userId, {
            name: attempt.userName,
            email: 'student@example.com',
            scores: []
          });
        }
        if (attempt.score !== undefined) {
          studentMap.get(attempt.userId)?.scores.push(attempt.score);
        }
      });
    });

    this.studentPerformances = Array.from(studentMap.entries()).map(([id, data]) => {
      const averageScore = data.scores.length > 0
        ? Math.round(data.scores.reduce((a, b) => a + b, 0) / data.scores.length)
        : 0;

      return {
        id,
        name: data.name,
        email: data.email,
        averageScore,
        testsTaken: data.scores.length,
        performance: this.getPerformanceCategory(averageScore)
      };
    });
  }

  private getPerformanceCategory(score: number): StudentPerformance['performance'] {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Good';
    if (score >= 70) return 'Average';
    if (score >= 60) return 'Poor';
    return 'Fail';
  }

  private updateChartData(): void {
    const activeStudents = this.studentPerformances.filter(s => s.testsTaken > 0);
    const distribution = {
      Excellent: 0,
      Good: 0,
      Average: 0,
      Poor: 0,
      Fail: 0
    };

    activeStudents.forEach(student => {
      distribution[student.performance]++;
    });

    this.pieChartData.datasets[0].data = [
      distribution.Excellent,
      distribution.Good,
      distribution.Average,
      distribution.Poor,
      distribution.Fail
    ];
  }

  getActiveStudentsCount(): number {
    return this.studentPerformances.filter(s => s.testsTaken > 0).length;
  }

  getAverageClassScore(): number {
    const activeStudents = this.studentPerformances.filter(s => s.testsTaken > 0);
    if (activeStudents.length === 0) return 0;
    
    const totalScore = activeStudents.reduce((sum, student) => sum + student.averageScore, 0);
    return Math.round(totalScore / activeStudents.length);
  }
}