import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';
import {
  PracticeTest,
  Question,
  TestAttempt,
} from '../../../../core/models/user.model';
import { PracticeTestService } from '../../../../core/services/practice-test.service';
import { AuthService } from '../../../../core/services/auth.service';

@Component({
  selector: 'app-practice-tests-section',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="space-y-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-xl font-semibold">Practice Tests</h2>
        <button *ngIf="isInstructor" (click)="showAddForm = true" class="btn-primary">
          Add Practice Test
        </button>
      </div>

      <!-- Add Test Form -->
      <div *ngIf="showAddForm" class="bg-gray-50 p-4 rounded-lg mb-6">
        <form [formGroup]="testForm" (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label for="title" class="block text-sm font-medium text-gray-700">Test Title</label>
            <input
              type="text"
              id="title"
              formControlName="title"
              class="form-input"
            />
          </div>

          <div>
            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              id="description"
              formControlName="description"
              rows="2"
              class="form-input"
            ></textarea>
          </div>

          <div>
            <label class="block text-sm font-medium text-gray-700">Questions Excel File</label>
            <input
              type="file"
              accept=".xlsx,.xls"
              (change)="onFileSelected($event)"
              class="mt-1 block w-full text-sm text-gray-500
                file:mr-4 file:py-2 file:px-4
                file:rounded-full file:border-0
                file:text-sm file:font-semibold
                file:bg-blue-50 file:text-blue-700
                hover:file:bg-blue-100"
            />
          </div>

          <div class="flex justify-end space-x-2">
            <button type="button" (click)="showAddForm = false" class="btn-danger">
              Cancel
            </button>
            <button type="submit" [disabled]="testForm.invalid || !selectedFile" class="btn-primary">
              Add Test
            </button>
          </div>
        </form>
      </div>

      <!-- Tests List -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div *ngFor="let test of tests" class="card">
          <div class="flex justify-between items-start">
            <div>
              <h3 class="text-lg font-semibold">{{ test.title }}</h3>
              <p class="text-gray-600 mt-1">{{ test.description }}</p>
              <div class="mt-2 space-y-1 text-sm text-gray-500">
                <p>Questions: {{ test.questions.length }}</p>
                <p>Total Points: {{ test.questions.length }}</p>
                <p>Duration: {{ test.questions.length * 3 }} minutes</p>
                <p>Created: {{ test.createdAt | date }}</p>
              </div>
            </div>
            <button 
              *ngIf="isInstructor"
              (click)="removeTest(test.id)"
              class="text-red-600 hover:text-red-800"
            >
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div class="mt-4 space-y-2">
            <button 
              *ngIf="!isInstructor"
              (click)="startTest(test)"
              class="w-full btn-primary"
            >
              Start Test
            </button>
            <button 
              *ngIf="!isInstructor && hasAttempted(test)"
              (click)="viewLastAttempt(test)"
              class="w-full btn-success"
            >
              View Last Attempt
            </button>
            <button 
              *ngIf="isInstructor"
              (click)="viewTest(test)"
              class="w-full btn-primary"
            >
              View Questions
            </button>
          </div>
        </div>
      </div>

      <!-- Test Taking Modal -->
      <div *ngIf="activeTest" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
        <div class="relative top-20 mx-auto p-5 border w-full max-w-4xl shadow-lg rounded-md bg-white">
          <div class="flex justify-between items-center mb-4">
            <div>
              <h3 class="text-xl font-bold">{{ activeTest.title }}</h3>
              <p *ngIf="!isInstructor && !viewingResults" class="text-sm text-gray-500">
                Time Remaining: {{ formatTime(timeRemaining) }}
              </p>
            </div>
            <button 
              (click)="closeTest()"
              class="text-gray-500 hover:text-gray-700"
              [disabled]="submitting"
            >
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div class="space-y-6 max-h-[60vh] overflow-y-auto p-4">
            <div *ngFor="let question of activeTest.questions; let i = index" class="p-4 bg-gray-50 rounded-lg">
              <p class="font-medium mb-4">{{ i + 1 }}. {{ question.text }}</p>
              
              <div class="space-y-2">
                <ng-container *ngIf="question.correctAnswers.length === 1; else multipleAnswers">
                  <!-- Single Answer (Radio Buttons) -->
                  <div *ngFor="let option of question.options; let j = index" class="flex items-center">
                    <input
                      *ngIf="!viewingResults"
                      type="radio"
                      [name]="'question' + i"
                      [id]="'q' + i + 'o' + j"
                      [checked]="isOptionSelected(question, option)"
                      (change)="selectSingleOption(question, option)"
                      [disabled]="viewingResults"
                      class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    >
                    <input
                      *ngIf="viewingResults"
                      type="radio"
                      [name]="'question' + i"
                      [id]="'q' + i + 'o' + j"
                      [checked]="isOptionSelected(question, option)"
                      disabled
                      class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    >
                    <label
                      [for]="'q' + i + 'o' + j"
                      class="ml-2 block text-sm"
                      [class.text-green-600]="viewingResults && isCorrectAnswer(question, option)"
                      [class.text-red-600]="viewingResults && isIncorrectSelection(question, option)"
                      [class.text-gray-900]="!viewingResults"
                    >
                      {{ option }}
                    </label>
                  </div>
                </ng-container>

                <ng-template #multipleAnswers>
                  <!-- Multiple Answers (Checkboxes) -->
                  <div *ngFor="let option of question.options; let j = index" class="flex items-center">
                    <input
                      *ngIf="!viewingResults"
                      type="checkbox"
                      [id]="'q' + i + 'o' + j"
                      [checked]="isOptionSelected(question, option)"
                      (change)="toggleOption(question, option)"
                      [disabled]="viewingResults"
                      class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    >
                    <input
                      *ngIf="viewingResults"
                      type="checkbox"
                      [id]="'q' + i + 'o' + j"
                      [checked]="isOptionSelected(question, option)"
                      disabled
                      class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    >
                    <label
                      [for]="'q' + i + 'o' + j"
                      class="ml-2 block text-sm"
                      [class.text-green-600]="viewingResults && isCorrectAnswer(question, option)"
                      [class.text-red-600]="viewingResults && isIncorrectSelection(question, option)"
                      [class.text-gray-900]="!viewingResults"
                    >
                      {{ option }}
                    </label>
                  </div>
                </ng-template>
              </div>

              <div *ngIf="viewingResults" class="mt-2 text-sm">
                <p class="text-gray-600">Correct answers: {{ question.correctAnswers.join(', ') }}</p>
                <p class="text-gray-600">Points: {{ isQuestionCorrect(question) ? '1' : '0' }}</p>
              </div>
            </div>
          </div>

          <div class="mt-6 flex justify-end space-x-2">
            <button
              *ngIf="!viewingResults && !isInstructor"
              (click)="submitTest()"
              class="btn-primary"
              [disabled]="submitting"
            >
              {{ submitting ? 'Submitting...' : 'Submit Test' }}
            </button>
            <button
              *ngIf="viewingResults && !isInstructor"
              (click)="retakeTest(activeTest)"
              class="btn-primary"
            >
              Retake Test
            </button>
          </div>

          <div *ngIf="viewingResults && lastAttempt" class="mt-4 p-4 bg-gray-50 rounded-lg">
            <h4 class="font-semibold">Test Results</h4>
            <p>Score: {{ lastAttempt.score }}%</p>
            <p>Points: {{ calculateTotalPoints() }} out of {{ activeTest.questions.length }}</p>
            <p>Completed: {{ lastAttempt.endTime | date:'medium' }}</p>
          </div>
        </div>
      </div>

      <div *ngIf="tests.length === 0" class="text-center py-8 text-gray-500">
        No practice tests available for this course.
      </div>
    </div>
  `,
})
export class PracticeTestsSectionComponent implements OnInit {
  @Input() courseId!: string;
  @Input() isInstructor = false;

  tests: PracticeTest[] = [];
  showAddForm = false;
  testForm: FormGroup;
  selectedFile: File | null = null;

  activeTest: PracticeTest | null = null;
  timeRemaining: number = 0;
  timerInterval: any;
  submitting = false;
  viewingResults = false;
  lastAttempt: TestAttempt | null = null;

  constructor(
    private fb: FormBuilder,
    private practiceTestService: PracticeTestService,
    private authService: AuthService
  ) {
    this.testForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.loadTests();
  }

  loadTests(): void {
    this.practiceTestService.getTests(this.courseId).subscribe({
      next: (tests) => {
        this.tests = tests;
      },
      error: (error) => {
        console.error('Error loading tests:', error);
      },
    });
  }

  onFileSelected(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }

  async onSubmit(): Promise<void> {
    if (this.testForm.valid && this.selectedFile) {
      try {
        const questions = await this.practiceTestService.processExcelFile(
          this.selectedFile
        );
        const testData = {
          ...this.testForm.value,
          courseId: this.courseId,
          questions,
        };

        this.practiceTestService.createTest(testData).subscribe({
          next: () => {
            this.loadTests();
            this.testForm.reset();
            this.selectedFile = null;
            this.showAddForm = false;
          },
          error: (error) => {
            console.error('Error creating test:', error);
          },
        });
      } catch (error) {
        console.error('Error processing file:', error);
      }
    }
  }

  startTest(test: PracticeTest): void {
    this.activeTest = {
      ...test,
      questions: test.questions.map((q) => ({ ...q, selectedAnswers: [] })),
    };
    this.viewingResults = false;
    this.lastAttempt = null;
    this.timeRemaining = test.questions.length * 3 * 60; // Convert to seconds
    this.startTimer();
  }

  viewTest(test: PracticeTest): void {
    this.activeTest = test;
    this.viewingResults = true;
  }

  viewLastAttempt(test: PracticeTest): void {
    const userId = this.authService.getCurrentUserValue()?.id;
    const attempts = test.attempts?.filter((a) => a.userId === userId) || [];
    if (attempts.length > 0) {
      this.lastAttempt = attempts[attempts.length - 1];
      this.activeTest = {
        ...test,
        questions: test.questions.map((q) => ({
          ...q,
          selectedAnswers:
            this.lastAttempt?.answers.find((a) => a.questionId === q.id)
              ?.selectedAnswers || [],
        })),
      };
      this.viewingResults = true;
    }
  }

  hasAttempted(test: PracticeTest): boolean {
    const userId = this.authService.getCurrentUserValue()?.id;
    return (test.attempts || []).some((a) => a.userId === userId);
  }

  retakeTest(test: PracticeTest): void {
    this.startTest(test);
  }

  closeTest(): void {
    if (!this.submitting) {
      this.activeTest = null;
      this.stopTimer();
      this.viewingResults = false;
      this.lastAttempt = null;
    }
  }

  private startTimer(): void {
    this.timerInterval = setInterval(() => {
      if (this.timeRemaining > 0) {
        this.timeRemaining--;
      } else {
        this.submitTest();
      }
    }, 1000);
  }

  private stopTimer(): void {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
  }

  formatTime(seconds: number): string {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }

  selectSingleOption(question: Question, option: string): void {
    question.selectedAnswers = [option];
  }

  toggleOption(question: Question, option: string): void {
    if (!question.selectedAnswers) {
      question.selectedAnswers = [];
    }

    const index = question.selectedAnswers.indexOf(option);
    if (index === -1) {
      question.selectedAnswers.push(option);
    } else {
      question.selectedAnswers.splice(index, 1);
    }
  }

  isOptionSelected(question: Question, option: string): boolean {
    return question.selectedAnswers?.includes(option) || false;
  }

  isCorrectAnswer(question: Question, option: string): boolean {
    return question.correctAnswers.includes(option);
  }

  isIncorrectSelection(question: Question, option: string): boolean {
    return (
      (question.selectedAnswers || []).includes(option) &&
      !question.correctAnswers.includes(option)
    );
  }

  isQuestionCorrect(question: Question): boolean {
    if (!question.selectedAnswers || !question.correctAnswers) return false;
    
    return (
      question.selectedAnswers.length === question.correctAnswers.length &&
      question.selectedAnswers.every(answer => question.correctAnswers.includes(answer))
    );
  }

  calculateTotalPoints(): number {
    if (!this.activeTest) return 0;
    return this.activeTest.questions.reduce((total, question) => 
      total + (this.isQuestionCorrect(question) ? 1 : 0), 0);
  }

  submitTest(): void {
    if (this.activeTest && !this.submitting) {
      this.submitting = true;
      this.stopTimer();

      const attempt: Partial<TestAttempt> = {
        startTime: new Date(
          Date.now() - this.timeRemaining * 1000
        ).toISOString(),
        endTime: new Date().toISOString(),
        answers: this.activeTest.questions.map((q) => ({
          questionId: q.id,
          selectedAnswers: q.selectedAnswers || [],
        })),
      };

      this.practiceTestService
        .submitTestAttempt(this.courseId, this.activeTest.id, attempt)
        .subscribe({
          next: () => {
            this.submitting = false;
            this.loadTests();
            this.closeTest();
          },
          error: (error) => {
            console.error('Error submitting test:', error);
            this.submitting = false;
          },
        });
    }
  }

  removeTest(testId: string): void {
    if (confirm('Are you sure you want to remove this test?')) {
      this.practiceTestService.deleteTest(this.courseId, testId).subscribe({
        next: () => {
          this.loadTests();
        },
        error: (error) => {
          console.error('Error removing test:', error);
        },
      });
    }
  }
}