import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { PracticeTestsSectionComponent } from './practice-tests-section.component';
import { PracticeTestService } from '../../../../core/services/practice-test.service';
import { AuthService } from '../../../../core/services/auth.service';
import { of } from 'rxjs';
import { Question } from '../../../../core/models/user.model';

describe('PracticeTestsSectionComponent', () => {
  let component: PracticeTestsSectionComponent;
  let fixture: ComponentFixture<PracticeTestsSectionComponent>;
  let practiceTestService: jasmine.SpyObj<PracticeTestService>;
  let authService: jasmine.SpyObj<AuthService>;

  const mockQuestion: Question = {
    id: 'q1',
    text: 'Test Question',
    options: ['A', 'B', 'C'],
    correctAnswers: ['A'],
    selectedAnswers: []
  };

  const mockTest = {
    id: '1',
    courseId: '1',
    title: 'Test Quiz',
    description: 'Test Description',
    duration: 60,
    questions: [mockQuestion],
    createdAt: '2024-02-20',
    attempts: []
  };

  beforeEach(async () => {
    const testSpy = jasmine.createSpyObj('PracticeTestService', 
      ['getTests', 'createTest', 'deleteTest', 'processExcelFile', 'submitTestAttempt']);
    const authSpy = jasmine.createSpyObj('AuthService', ['getCurrentUserValue']);

    testSpy.getTests.and.returnValue(of([mockTest]));
    authSpy.getCurrentUserValue.and.returnValue({ id: '1', name: 'Test User' });

    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, PracticeTestsSectionComponent],
      providers: [
        { provide: PracticeTestService, useValue: testSpy },
        { provide: AuthService, useValue: authSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(PracticeTestsSectionComponent);
    component = fixture.componentInstance;
    practiceTestService = TestBed.inject(PracticeTestService) as jasmine.SpyObj<PracticeTestService>;
    authService = TestBed.inject(AuthService) as jasmine.SpyObj<AuthService>;
    component.courseId = '1';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('answer handling', () => {
    it('should handle single option selection', () => {
      const question = { ...mockQuestion };
      component.selectSingleOption(question, 'A');
      expect(question.selectedAnswers).toEqual(['A']);
    });

    it('should handle option toggling', () => {
      const question = { ...mockQuestion };
      component.toggleOption(question, 'A');
      expect(question.selectedAnswers).toEqual(['A']);
      component.toggleOption(question, 'A');
      expect(question.selectedAnswers).toEqual([]);
    });

    it('should validate correct answers', () => {
      const question = { ...mockQuestion, selectedAnswers: ['A'] };
      expect(component.isQuestionCorrect(question)).toBeTrue();
      question.selectedAnswers = ['B'];
      expect(component.isQuestionCorrect(question)).toBeFalse();
    });
  });
});