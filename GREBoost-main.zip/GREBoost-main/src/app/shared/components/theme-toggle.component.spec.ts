import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ThemeToggleComponent } from './theme-toggle.component';
import { ThemeService } from '../../core/services/theme.service';
import { BehaviorSubject } from 'rxjs';

describe('ThemeToggleComponent', () => {
  let component: ThemeToggleComponent;
  let fixture: ComponentFixture<ThemeToggleComponent>;
  let themeService: jasmine.SpyObj<ThemeService>;

  beforeEach(async () => {
    const themeSpy = jasmine.createSpyObj('ThemeService', ['toggleTheme'], {
      darkMode$: new BehaviorSubject(false)
    });

    await TestBed.configureTestingModule({
      imports: [ThemeToggleComponent],
      providers: [
        { provide: ThemeService, useValue: themeSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ThemeToggleComponent);
    component = fixture.componentInstance;
    themeService = TestBed.inject(ThemeService) as jasmine.SpyObj<ThemeService>;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle theme when clicked', () => {
    component.toggleTheme();
    expect(themeService.toggleTheme).toHaveBeenCalled();
  });

  it('should display correct icon based on theme', () => {
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('svg')).toBeTruthy();
    
    (themeService.darkMode$ as BehaviorSubject<boolean>).next(true);
    fixture.detectChanges();
    expect(compiled.querySelector('svg')).toBeTruthy();
  });
});