import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { User } from '../../core/models/user.model';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-profile-dropdown',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="relative" *ngIf="showDropdown">
      <button 
        (click)="toggleMenu()"
        class="flex items-center space-x-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white focus:outline-none"
      >
        <div class="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
          {{ getUserInitials() }}
        </div>
        <svg 
          class="w-4 h-4 transition-transform duration-200"
          [class.rotate-180]="isOpen"
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      <!-- Dropdown Menu -->
      <div 
        *ngIf="isOpen"
        class="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white dark:bg-gray-700 ring-1 ring-black ring-opacity-5 z-50"
      >
        <div class="py-1">
          <!-- User Info -->
          <div class="px-4 py-2 border-b border-gray-200 dark:border-gray-600">
            <p class="text-sm font-medium text-gray-900 dark:text-white">{{ user?.name }}</p>
            <p class="text-sm text-gray-500 dark:text-gray-300">{{ user?.email }}</p>
            <p class="text-xs text-gray-500 dark:text-gray-400 capitalize mt-1">{{ user?.role }}</p>
          </div>
          
          <!-- Logout Button -->
          <button 
            (click)="logout()" 
            class="w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-600"
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  `
})
export class ProfileDropdownComponent implements OnInit {
  isOpen = false;
  user: User | null = null;
  showDropdown = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    // Close dropdown when clicking outside
    window.addEventListener('click', (e: any) => {
      if (!e.target.closest('.relative')) {
        this.isOpen = false;
      }
    });

    // Update visibility on route changes
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.updateDropdownVisibility(event.url);
    });
  }

  ngOnInit(): void {
    // Get initial user data and visibility
    this.user = this.authService.getCurrentUserValue();
    this.updateDropdownVisibility(this.router.url);
  }

  private updateDropdownVisibility(url: string): void {
    this.showDropdown = !url.includes('login') && 
                       !url.includes('signup') && 
                       this.authService.isAuthenticated();
  }

  toggleMenu(): void {
    this.isOpen = !this.isOpen;
  }

  getUserInitials(): string {
    if (!this.user?.name) return '';
    return this.user.name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase();
  }

  logout(): void {
    this.isOpen = false;
    this.authService.logout();
  }
}