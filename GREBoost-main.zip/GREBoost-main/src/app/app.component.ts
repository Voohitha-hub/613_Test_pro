import { Component } from '@angular/core';
import { RouterOutlet, Router, NavigationEnd } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { CommonModule } from '@angular/common';
import { filter } from 'rxjs/operators';
import { ThemeToggleComponent } from './shared/components/theme-toggle.component';
import { ProfileDropdownComponent } from './shared/components/profile-dropdown.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, ThemeToggleComponent, ProfileDropdownComponent],
  template: `
    <div class="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-200">
      <!-- Only show nav when authenticated and not on auth pages -->
      <nav *ngIf="showNav" class="bg-white dark:bg-gray-800 shadow-md dark:shadow-gray-700/30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between h-16">
            <div class="flex items-center space-x-4">
              <button 
                *ngIf="showBackButton"
                (click)="goBack()" 
                class="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors duration-200"
                aria-label="Go back"
              >
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
              </button>
              <span class="text-xl font-bold text-gray-900 dark:text-white">GREBoost</span>
            </div>
            <div class="flex items-center space-x-4">
              <app-theme-toggle></app-theme-toggle>
              <app-profile-dropdown></app-profile-dropdown>
            </div>
          </div>
        </div>
      </nav>
      
      <main>
        <router-outlet></router-outlet>
      </main>
    </div>
  `
})
export class AppComponent {
  showNav = false;
  showBackButton = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    // Hide navigation on auth pages and manage back button visibility
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.showNav = !event.url.includes('login') && 
                    !event.url.includes('signup') && 
                    this.authService.isAuthenticated();
      
      // Show back button only on course detail pages
      this.showBackButton = event.url.includes('/courses/') && 
                           !event.url.endsWith('/courses');
    });
  }

  goBack(): void {
    this.router.navigate(['/dashboard']);
  }
}