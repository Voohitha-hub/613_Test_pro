"""Utility functions for MongoDB operations"""
from bson import ObjectId

def serialize_id(obj):
    """Convert MongoDB _id to string id"""
    if isinstance(obj, dict):
        if '_id' in obj:
            obj['id'] = str(obj['_id'])
            del obj['_id']
    return obj

def serialize_list(items):
    """Serialize a list of MongoDB documents"""
    return [serialize_id(item) for item in items]

def parse_object_id(id_str):
    """Safely parse string ID to ObjectId"""
    try:
        return ObjectId(id_str)
    except:
        return None

def handle_db_operation(operation, fallback_data=None):
    """Handle database operations with fallback to mock data"""
    try:
        result = operation()
        return result
    except Exception as e:
        print(f"Database operation failed: {e}")
        return fallback_data