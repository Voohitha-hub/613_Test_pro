import pytest
from app import app, db
from flask_jwt_extended import create_access_token

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.drop_all()

def test_signup(client):
    response = client.post('/api/auth/signup', json={
        'email': 'test@example.com',
        'password': 'password123',
        'name': 'Test User',
        'role': 'student'
    })
    assert response.status_code == 201
    assert b'Account created successfully' in response.data

def test_login(client):
    # Create test user
    client.post('/api/auth/signup', json={
        'email': 'test@example.com',
        'password': 'password123',
        'name': 'Test User',
        'role': 'student'
    })
    
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'password123'
    })
    assert response.status_code == 200
    assert 'token' in response.json

def test_profile(client):
    # Create and login user
    client.post('/api/auth/signup', json={
        'email': 'test@example.com',
        'password': 'password123',
        'name': 'Test User',
        'role': 'student'
    })
    login_response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'password123'
    })
    token = login_response.json['token']
    
    response = client.get('/api/auth/profile', 
                         headers={'Authorization': f'Bearer {token}'})
    assert response.status_code == 200
    assert response.json['email'] == 'test@example.com'