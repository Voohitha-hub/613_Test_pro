"""Mock data for fallback when database is not available"""

MOCK_USERS = [
    {
        "id": "1",
        "email": "student@example.com",
        "password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY.5AYJZjqvQk.2",  # student123
        "name": "John Student",
        "role": "student"
    },
    {
        "id": "2",
        "email": "instructor@example.com",
        "password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY.5AYJZjqvQk.2",  # instructor123
        "name": "Jane Instructor",
        "role": "instructor"
    },
    {
        "id": "3",
        "email": "admin@example.com",
        "password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY.5AYJZjqvQk.2",  # admin123
        "name": "Admin User",
        "role": "admin"
    }
]

MOCK_COURSES = [
    {
        "id": "1",
        "name": "GRE Quantitative Reasoning",
        "description": "Master GRE math concepts and problem-solving strategies",
        "duration": "8 weeks",
        "instructor_id": "2",
        "instructor_name": "Jane Instructor",
        "enrolled_students": 25,
        "content": {
            "chapters": [
                {
                    "id": "1",
                    "title": "Introduction to GRE Math",
                    "order": 1,
                    "lecture": {
                        "id": "v1",
                        "title": "GRE Math Overview",
                        "video_url": "https://www.youtube.com/embed/dQw4w9WgXcQ",
                        "description": "Comprehensive overview of GRE Quantitative section"
                    },
                    "slides": {
                        "id": "s1",
                        "title": "GRE Math Introduction Slides",
                        "file_url": "data:application/pdf;base64,JVBERi0..."
                    },
                    "quiz": {
                        "id": "q1",
                        "title": "Introduction Quiz",
                        "questions": [
                            {
                                "id": "q1_1",
                                "text": "What is the main focus of GRE Quantitative section?",
                                "options": [
                                    "Basic arithmetic",
                                    "Advanced calculus",
                                    "Problem-solving and quantitative reasoning",
                                    "Theoretical mathematics"
                                ],
                                "correct_answers": ["Problem-solving and quantitative reasoning"]
                            }
                        ]
                    }
                }
            ]
        }
    }
]

MOCK_FLASHCARDS = {
    "1": [
        {
            "id": 1,
            "question": "What is a derivative?",
            "answer": "Rate of change of a function",
            "is_flipped": False
        },
        {
            "id": 2,
            "question": "Define integral",
            "answer": "Area under a curve",
            "is_flipped": False
        }
    ]
}

MOCK_ANNOUNCEMENTS = {
    "1": [
        {
            "id": "1",
            "course_id": "1",
            "title": "Welcome to GRE Quantitative Reasoning!",
            "content": "Welcome to our comprehensive GRE preparation course!",
            "created_by": "Jane Instructor",
            "date": "2024-02-17"
        }
    ]
}

MOCK_PRACTICE_TESTS = {
    "1": [
        {
            "id": "1",
            "course_id": "1",
            "title": "Quantitative Practice Test 1",
            "description": "Basic algebra and arithmetic concepts",
            "duration": 60,
            "questions": [
                {
                    "id": "q1",
                    "text": "What is 2 + 2?",
                    "options": ["3", "4", "5", "6"],
                    "correct_answers": ["4"]
                }
            ],
            "attempts": [],
            "created_at": "2024-02-17"
        }
    ]
}

MOCK_REQUESTS = [
    {
        "id": "1",
        "type": "instructor_account",
        "status": "pending",
        "user_data": {
            "name": "New Instructor",
            "email": "new.instructor@example.com",
            "role": "instructor"
        },
        "date": "2024-02-17"
    }
]