from flask import Flask
from models import init_app
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv
from flask_pymongo import PyMongo
import os

load_dotenv()

app = Flask(__name__)
app.config['MONGO_URI'] = "mongodb+srv://vercel-admin-user:2CrBBE4tvCoYXOqb@cluster0.gfh7y.mongodb.net/myFirstDatabase?retryWrites=true&w=majority&ssl=true&tlsAllowInvalidCertificates=true"
app.config['JWT_SECRET_KEY'] = "your-secret-key-here"

mongo = PyMongo(app)

# Expose the db globally
db = mongo.db

# Initialize extensions
with app.app_context():
    init_app(db)

jwt = JWTManager(app)
bcrypt = Bcrypt(app)
CORS(app)

# Import routes after initializing extensions to avoid circular imports
from routes.auth_routes import bp as auth_bp
from routes.course_routes import bp as course_bp
from routes.test_routes import bp as test_bp
from routes.flashcard_routes import bp as flashcard_bp
from routes.announcement_routes import bp as announcement_bp
from routes.request_routes import bp as request_bp

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(course_bp)
app.register_blueprint(test_bp)
app.register_blueprint(flashcard_bp)
app.register_blueprint(announcement_bp)
app.register_blueprint(request_bp)

if __name__ == '__main__':
    app.run(debug=True)