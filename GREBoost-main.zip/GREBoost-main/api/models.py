

# Schema validation for MongoDB collections
USER_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["email", "password", "name", "role"],
            "properties": {
                "email": {
                    "bsonType": "string",
                    "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
                },
                "password": {"bsonType": "string"},
                "name": {"bsonType": "string"},
                "role": {
                    "enum": ["student", "instructor", "admin"]
                },
                "created_at": {
                    "bsonType": "date",
                    "description": "Must be a date"
                }
            }
        }
    }
}

COURSE_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["name", "description", "duration", "instructor_id"],
            "properties": {
                "name": {"bsonType": "string"},
                "description": {"bsonType": "string"},
                "duration": {"bsonType": "string"},
                "instructor_id": {"bsonType": "string"},
                "instructor_name": {"bsonType": "string"},
                "enrolled_students": {"bsonType": "int"},
                "content": {
                    "bsonType": "object",
                    "properties": {
                        "chapters": {
                            "bsonType": "array",
                            "items": {
                                "bsonType": "object",
                                "required": ["id", "title", "order", "lecture"],
                                "properties": {
                                    "id": {"bsonType": "string"},
                                    "title": {"bsonType": "string"},
                                    "order": {"bsonType": "int"},
                                    "lecture": {
                                        "bsonType": "object",
                                        "required": ["id", "title", "video_url", "description"],
                                        "properties": {
                                            "id": {"bsonType": "string"},
                                            "title": {"bsonType": "string"},
                                            "video_url": {"bsonType": "string"},
                                            "description": {"bsonType": "string"}
                                        }
                                    },
                                    "slides": {
                                        "bsonType": "object",
                                        "properties": {
                                            "id": {"bsonType": "string"},
                                            "title": {"bsonType": "string"},
                                            "file_url": {"bsonType": "string"}
                                        }
                                    },
                                    "quiz": {
                                        "bsonType": "object",
                                        "properties": {
                                            "id": {"bsonType": "string"},
                                            "title": {"bsonType": "string"},
                                            "questions": {
                                                "bsonType": "array",
                                                "items": {
                                                    "bsonType": "object",
                                                    "required": ["id", "text", "options", "correct_answers"],
                                                    "properties": {
                                                        "id": {"bsonType": "string"},
                                                        "text": {"bsonType": "string"},
                                                        "options": {
                                                            "bsonType": "array",
                                                            "items": {"bsonType": "string"}
                                                        },
                                                        "correct_answers": {
                                                            "bsonType": "array",
                                                            "items": {"bsonType": "string"}
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "created_at": {"bsonType": "date"}
            }
        }
    }
}

ENROLLMENT_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["student_id", "course_id"],
            "properties": {
                "student_id": {"bsonType": "string"},
                "course_id": {"bsonType": "string"},
                "progress": {"bsonType": "double"},
                "enrolled_at": {"bsonType": "date"}
            }
        }
    }
}

FLASHCARD_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["course_id", "question", "answer"],
            "properties": {
                "course_id": {"bsonType": "string"},
                "question": {"bsonType": "string"},
                "answer": {"bsonType": "string"},
                "is_flipped": {"bsonType": "bool"},
                "created_at": {"bsonType": "date"}
            }
        }
    }
}

PRACTICE_TEST_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["course_id", "title", "description", "duration"],
            "properties": {
                "course_id": {"bsonType": "string"},
                "title": {"bsonType": "string"},
                "description": {"bsonType": "string"},
                "duration": {"bsonType": "int"},
                "questions": {
                    "bsonType": "array",
                    "items": {
                        "bsonType": "object",
                        "required": ["id", "text", "options", "correct_answers"],
                        "properties": {
                            "id": {"bsonType": "string"},
                            "text": {"bsonType": "string"},
                            "options": {
                                "bsonType": "array",
                                "items": {"bsonType": "string"}
                            },
                            "correct_answers": {
                                "bsonType": "array",
                                "items": {"bsonType": "string"}
                            }
                        }
                    }
                },
                "attempts": {
                    "bsonType": "array",
                    "items": {
                        "bsonType": "object",
                        "required": ["user_id", "start_time"],
                        "properties": {
                            "user_id": {"bsonType": "string"},
                            "start_time": {"bsonType": "date"},
                            "end_time": {"bsonType": "date"},
                            "score": {"bsonType": "double"},
                            "answers": {
                                "bsonType": "array",
                                "items": {
                                    "bsonType": "object",
                                    "properties": {
                                        "question_id": {"bsonType": "string"},
                                        "selected_answers": {
                                            "bsonType": "array",
                                            "items": {"bsonType": "string"}
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                "created_at": {"bsonType": "date"}
            }
        }
    }
}

ANNOUNCEMENT_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["course_id", "title", "content", "created_by"],
            "properties": {
                "course_id": {"bsonType": "string"},
                "title": {"bsonType": "string"},
                "content": {"bsonType": "string"},
                "created_by": {"bsonType": "string"},
            }
        }
    }
}

REQUEST_SCHEMA = {
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "required": ["type", "status", "user_data"],
            "properties": {
                "type": {
                    "enum": ["student_registration", "instructor_account"]
                },
                "status": {
                    "enum": ["pending", "approved", "denied"]
                },
                "user_data": {"bsonType": "object"},
                "created_at": {"bsonType": "date"}
            }
        }
    }
}

# Initialize the `models` dictionary to store the collections
models = {}

def init_collections(db):
    """Initialize MongoDB collections with schema validation"""
    collections = {
        'users': USER_SCHEMA,
        'courses': COURSE_SCHEMA,
        'enrollments': ENROLLMENT_SCHEMA,
        'flashcards': FLASHCARD_SCHEMA,
        'practice_tests': PRACTICE_TEST_SCHEMA,
        'announcements': ANNOUNCEMENT_SCHEMA,
        'requests': REQUEST_SCHEMA
    }

    for collection_name, schema in collections.items():
        # Check if the collection exists
        if collection_name not in db.list_collection_names():
            # Create the collection with schema validation
            db.create_collection(collection_name, validator=schema['validator'])


def create_indexes(db):
    """Create necessary indexes for collections"""
    db.users.create_index('email', unique=True)
    db.courses.create_index('instructor_id')
    db.enrollments.create_index([('student_id', 1), ('course_id', 1)], unique=True)
    db.flashcards.create_index('course_id')
    db.practice_tests.create_index('course_id')
    db.announcements.create_index('course_id')
    db.announcements.create_index('created_at')
    db.requests.create_index('status')
    db.requests.create_index('created_at')

def init_app(db):
    """Initialize the MongoDB schemas and export collections"""
    # Initialize MongoDB using Flask-PyMongo or pymongo client
    # if 'pymongo' in app.extensions:
    #     db = app.extensions['pymongo'].db
    # else:
    #     client = MongoClient(app.config['MONGO_URI'])
    #     db = client.get_default_database()

    # Apply schema validation and indexing
    init_collections(db)
    create_indexes(db)

    # Store initialized collections in the `models` dictionary
    global models
    models = {
        'users': db['users'],
        'courses': db['courses'],
        'enrollments': db['enrollments'],
        'flashcards': db['flashcards'],
        'practice_tests': db['practice_tests'],
        'announcements': db['announcements'],
        'requests': db['requests']
    }
