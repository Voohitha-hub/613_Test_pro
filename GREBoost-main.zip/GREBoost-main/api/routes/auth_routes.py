from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from app import bcrypt, db  # Ensure `db` is initialized as the MongoDB client
from bson import ObjectId
import mock_data

bp = Blueprint('auth', __name__, url_prefix='/api/auth')

def get_user_by_email(email):
    """Fetch user by email from MongoDB or mock data."""
    try:
        user = db.users.find_one({"email": email})  # MongoDB collection for users
        if user:
            user['_id'] = str(user['_id'])  # Convert ObjectId to string for JSON compatibility
        return user
    except Exception as e:
        print(f"Error fetching user by email: {e}")
        # Fallback to mock data
        return next((user for user in mock_data.MOCK_USERS if user["email"] == email), None)


@bp.route('/login', methods=['POST'])
def login():
    """User login route."""
    data = request.get_json()
    user = get_user_by_email(data.get('email'))

    if user and bcrypt.check_password_hash(user['password'], data['password']):
        access_token = create_access_token(identity=user['_id'])
        print("reached here", user, access_token)
        return jsonify({
            'token': access_token,
            'user': {
                'id': user['_id'],
                'email': user['email'],
                'name': user['name'],
                'role': user['role']
            }
        }), 200

    return jsonify({'error': 'Invalid credentials'}), 401



@bp.route('/signup', methods=['POST'])
def signup():
    """User signup route."""
    data = request.get_json()
    try:
        # Check if the email already exists
        if db.users.find_one({"email": data['email']}):
            return jsonify({'error': 'Email already exists'}), 400
        # Handle instructor requests
        if data.get('role') == 'instructor':
            db.requests.insert_one({
                'type': 'instructor_account',
                'status': 'pending',
                'user_data': data
            })
            return jsonify({'message': 'Instructor request submitted'}), 201

        # Create a new user
        hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
        new_user = {
            'email': data['email'],
            'password': hashed_password,
            'name': data['name'],
            'role': 'student'
        }
        print("reached here")
        db.users.insert_one(new_user)
        print("reached here")
        return jsonify({'message': 'Account created successfully'}), 201

    except Exception as e:
        print(f"Error during signup: {e}")
        return jsonify({'error': 'An error occurred while processing your request'}), 500
    


@bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get user profile route."""
    user_id = get_jwt_identity()

    try:
        # Fetch the user from the database
        user = db.users.find_one({"_id": ObjectId(user_id)})
        if user:
            return jsonify({
                'id': str(user['_id']),
                'email': user['email'],
                'name': user['name'],
                'role': user['role']
            }), 200

    except Exception as e:
        print(f"Error fetching user profile: {e}")

        # Fallback to mock data
        user = next((u for u in mock_data.MOCK_USERS if u['id'] == user_id), None)
        if user:
            return jsonify({
                'id': user['id'],
                'email': user['email'],
                'name': user['name'],
                'role': user['role']
            }), 200

    return jsonify({'error': 'User not found'}), 404