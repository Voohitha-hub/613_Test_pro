from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime

bp = Blueprint('tests', __name__, url_prefix='/api/tests')

@bp.route('/course/<int:course_id>', methods=['GET'])
@jwt_required()
def get_tests(course_id):
    tests = PracticeTest.query.filter_by(course_id=course_id).all()
    return jsonify([{
        'id': test.id,
        'courseId': test.course_id,
        'title': test.title,
        'description': test.description,
        'duration': test.duration,
        'questions': [{
            'id': q.id,
            'text': q.text,
            'options': q.options,
            'correctAnswers': q.correct_answers
        } for q in test.questions],
        'attempts': [{
            'id': a.id,
            'userId': a.user_id,
            'userName': User.query.get(a.user_id).name,
            'startTime': a.start_time.isoformat(),
            'endTime': a.end_time.isoformat() if a.end_time else None,
            'score': a.score,
            'answers': a.answers
        } for a in test.attempts],
        'createdAt': test.created_at.isoformat()
    } for test in tests]), 200

@bp.route('/course/<int:course_id>', methods=['POST'])
@jwt_required()
def create_test(course_id):
    data = request.get_json()
    
    new_test = PracticeTest(
        course_id=course_id,
        title=data['title'],
        description=data['description'],
        duration=data['duration']
    )
    db.session.add(new_test)
    
    for q_data in data['questions']:
        question = TestQuestion(
            test_id=new_test.id,
            text=q_data['text'],
            options=q_data['options'],
            correct_answers=q_data['correctAnswers']
        )
        db.session.add(question)
    
    db.session.commit()
    return jsonify({'message': 'Test created successfully'}), 201

@bp.route('/<int:test_id>/attempt', methods=['POST'])
@jwt_required()
def submit_attempt(test_id):
    user_id = get_jwt_identity()
    data = request.get_json()
    
    attempt = TestAttempt(
        test_id=test_id,
        user_id=user_id,
        start_time=datetime.fromisoformat(data['startTime']),
        end_time=datetime.fromisoformat(data['endTime']),
        score=data['score'],
        answers=data['answers']
    )
    db.session.add(attempt)
    db.session.commit()
    
    return jsonify({'message': 'Attempt submitted successfully'}), 201

@bp.route('/<int:test_id>', methods=['DELETE'])
@jwt_required()
def delete_test(test_id):
    test = PracticeTest.query.get_or_404(test_id)
    db.session.delete(test)
    db.session.commit()
    return jsonify({'message': 'Test deleted successfully'}), 200