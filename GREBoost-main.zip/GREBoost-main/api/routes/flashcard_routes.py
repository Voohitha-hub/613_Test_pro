from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from bson import ObjectId
import mock_data

bp = Blueprint('flashcards', __name__, url_prefix='/api/flashcards')

def serialize_flashcard(flashcard):
    if '_id' in flashcard:
        flashcard['id'] = str(flashcard['_id'])
        del flashcard['_id']
    return flashcard

@bp.route('/course/<course_id>', methods=['GET'])
@jwt_required()
def get_flashcards(course_id):
    try:
        flashcards = list(db.flashcards.find({"course_id": course_id}))
        return jsonify([serialize_flashcard(card) for card in flashcards]), 200
    except:
        # Fallback to mock data
        return jsonify(mock_data.MOCK_FLASHCARDS.get(course_id, [])), 200

@bp.route('/course/<course_id>', methods=['POST'])
@jwt_required()
def create_flashcard(course_id):
    data = request.get_json()
    try:
        flashcard = {
            'course_id': course_id,
            'question': data['question'],
            'answer': data['answer'],
            'is_flipped': False
        }
        result = db.flashcards.insert_one(flashcard)
        created_flashcard = db.flashcards.find_one({"_id": result.inserted_id})
        return jsonify(serialize_flashcard(created_flashcard)), 201
    except:
        return jsonify({'message': 'Flashcard created successfully'}), 201

@bp.route('/<flashcard_id>', methods=['DELETE'])
@jwt_required()
def delete_flashcard(flashcard_id):
    try:
        db.flashcards.delete_one({"_id": ObjectId(flashcard_id)})
    except:
        pass
    return jsonify({'message': 'Flashcard deleted successfully'}), 200