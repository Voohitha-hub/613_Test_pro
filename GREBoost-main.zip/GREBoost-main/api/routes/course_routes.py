
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from bson import ObjectId
from models import models
from datetime import datetime
from flask_cors import CORS

bp = Blueprint('courses', __name__, url_prefix='/api/courses')
bp.strict_slashes = False



def serialize_course(course):
    # Serialize MongoDB course documents for JSON responses.
    if '_id' in course:
        course['id'] = str(course['_id'])
        del course['_id']
    return course


@bp.route('/', methods=['GET'])
@jwt_required()
def get_courses():
    # Get all courses.
    print("reached here")
    try:
        courses = list(models['courses'].find())
        return jsonify([serialize_course(course) for course in courses]), 200
    except Exception as e:
        return jsonify({'error': f'Failed to fetch courses: {str(e)}'}), 500


@bp.route('/<course_id>', methods=['GET'])
@jwt_required()
def get_course(course_id):
    # Get a specific course by ID.
    try:
        course = models['courses'].find_one({"_id": ObjectId(course_id)})
        if course:
            return jsonify(serialize_course(course)), 200
        return jsonify({'error': 'Course not found'}), 404
    except Exception as e:
        return jsonify({'error': f'Failed to fetch course: {str(e)}'}), 500


@bp.route('/enrolled', methods=['GET'])
@jwt_required()
def get_enrolled_courses():
    # Get courses the current user is enrolled in.
    user_id = get_jwt_identity()
    try:
        enrollments = list(models['enrollments'].find({"student_id": user_id}))
        course_ids = [enrollment['course_id'] for enrollment in enrollments]
        courses = list(models['courses'].find({"_id": {"$in": [ObjectId(cid) for cid in course_ids]}}))
        return jsonify([serialize_course(course) for course in courses]), 200
    except Exception as e:
        return jsonify({'error': f'Failed to fetch enrolled courses: {str(e)}'}), 500


@bp.route('/available', methods=['GET'])
@jwt_required()
def get_available_courses():
    # Get courses available for enrollment.
    user_id = get_jwt_identity()
    try:
        enrollments = list(models['enrollments'].find({"student_id": user_id}))
        enrolled_course_ids = {enrollment['course_id'] for enrollment in enrollments}
        courses = list(models['courses'].find({"_id": {"$nin": [ObjectId(cid) for cid in enrolled_course_ids]}}))
        return jsonify([serialize_course(course) for course in courses]), 200
    except Exception as e:
        return jsonify({'error': f'Failed to fetch available courses: {str(e)}'}), 500


@bp.route('/<course_id>/enroll', methods=['POST'])
@jwt_required()
def enroll_course(course_id):
    # Enroll the current user in a course.
    user_id = get_jwt_identity()
    try:
        enrollment = {
            'student_id': user_id,
            'course_id': course_id,
            'progress': 0.0,
            'enrolled_at': datetime.utcnow()
        }
        models['enrollments'].insert_one(enrollment)
        return jsonify({'message': 'Enrolled successfully'}), 201
    except Exception as e:
        return jsonify({'error': f'Failed to enroll in course: {str(e)}'}), 500



@bp.route('', methods=['POST'])  # No trailing slash
@jwt_required()
def create_course():
    # Create a new course.
    data = request.get_json()
    user_id = get_jwt_identity()
    try:
        # Validate that the user is an admin
        admin = models['users'].find_one({"_id": ObjectId(user_id), "role": "admin"})
        print("reached here",admin)
        if not admin:
            return jsonify({'error': 'Only admins can create courses'}), 403

        # Handle optional instructor name
        instructor_name = data.get("instructorName")
        instructor_id = None
        if instructor_name:
            print("reached here",instructor_name)
            instructor = models['users'].find_one({"name": instructor_name, "role": "instructor"})
            print("reached here",instructor)
            if not instructor:
                return jsonify({'error': f'Instructor "{instructor_name}" not found'}), 404
            instructor_id = str(instructor["_id"])

        # Prepare course data
        new_course = {
            "name": data.get("name"),
            "description": data.get("description"),
            "duration": data.get("duration"),
            "instructor_id": instructor_id,
            "instructor_name": instructor_name,
            "enrolled_students": 0,
            "content": {"chapters": []},
            "created_at": datetime.utcnow()
        }

        # Insert the course into the database
        result = models['courses'].insert_one(new_course)
        created_course = models['courses'].find_one({"_id": result.inserted_id})

        return jsonify(serialize_course(created_course)), 201
    except Exception as e:
        return jsonify({'error': f'Failed to create course: {str(e)}'}), 500


@bp.route('/<course_id>', methods=['PUT'])
@jwt_required()
def update_course(course_id):
    # Update an existing course.
    data = request.get_json()
    user_id = get_jwt_identity()

    try:
        # Validate that the user is an admin
        admin = models['users'].find_one({"_id": ObjectId(user_id), "role": "admin"})
        if not admin:
            return jsonify({'error': 'Only admins can update courses'}), 403

        # Fetch the course
        course = models['courses'].find_one({"_id": ObjectId(course_id)})
        if not course:
            return jsonify({'error': 'Course not found'}), 404

        # Handle optional instructor name
        instructor_name = data.get("instructor_name")
        instructor_id = None
        if instructor_name:
            instructor = models['users'].find_one({"name": instructor_name, "role": "instructor"})
            if not instructor:
                return jsonify({'error': f'Instructor "{instructor_name}" not found'}), 404
            instructor_id = str(instructor["_id"])
            data["instructor_id"] = instructor_id

        # Update allowed fields
        allowed_updates = ["name", "description", "duration", "content", "instructor_name", "instructor_id"]
        updates = {key: value for key, value in data.items() if key in allowed_updates}
        updates["updated_at"] = datetime.utcnow()

        # Perform the update
        models['courses'].update_one({"_id": ObjectId(course_id)}, {"$set": updates})
        updated_course = models['courses'].find_one({"_id": ObjectId(course_id)})

        return jsonify(serialize_course(updated_course)), 200
    except Exception as e:
        return jsonify({'error': f'Failed to update course: {str(e)}'}), 500

@bp.route('/instructor/assigned', methods=['GET'])
@jwt_required()
def get_instructor_courses():
    """Get courses assigned to the logged-in instructor"""
    instructor_id = get_jwt_identity()
    print("reached here",instructor_id)
    try:
        # Query MongoDB for courses assigned to the instructor
        courses = list(models['courses'].find({"instructor_id": instructor_id}))
        return jsonify([serialize_course(course) for course in courses]), 200
    except Exception as e:
        print(f"Error fetching assigned courses for instructor {instructor_id}: {e}")
        return jsonify({'error': f'Failed to fetch assigned courses: {str(e)}'}), 500
    
@bp.route('/<course_id>/chapters', methods=['POST'])
@jwt_required()
def add_chapter(course_id):
    """Add a chapter to a specific course"""
    user_id = get_jwt_identity()
    try:
        # Validate that the user is an instructor or admin
        user = models['users'].find_one({"_id": ObjectId(user_id)})
        if not user or user['role'] not in ['instructor', 'admin']:
            return jsonify({'error': 'Unauthorized: Only instructors or admins can add chapters'}), 403

        # Get the course
        course = models['courses'].find_one({"_id": ObjectId(course_id)})
        if not course:
            return jsonify({'error': 'Course not found'}), 404

        # Get chapter data from request
        data = request.get_json()
        new_chapter = {
            "id": str(ObjectId()),
            "title": data.get("title"),
            "content": data.get("content"),
            "video_url": data.get("video_url"),
            "created_at": datetime.utcnow()
        }

        # Append the new chapter to the course's content
        models['courses'].update_one(
            {"_id": ObjectId(course_id)},
            {"$push": {"content.chapters": new_chapter}}
        )

        # Return the updated course
        updated_course = models['courses'].find_one({"_id": ObjectId(course_id)})
        return jsonify(serialize_course(updated_course)), 200
    except Exception as e:
        return jsonify({'error': f'Failed to add chapter: {str(e)}'}), 500
