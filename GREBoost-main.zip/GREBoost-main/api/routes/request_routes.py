from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from bson import ObjectId
from datetime import datetime
from app import db, bcrypt
import mock_data

bp = Blueprint('requests', __name__, url_prefix='/api/requests')


def serialize_id(doc):
    """Serialize MongoDB documents by converting ObjectId to string."""
    if '_id' in doc:
        doc['id'] = str(doc['_id'])
        del doc['_id']
    return doc


@bp.route('/pending', methods=['GET'])
@jwt_required()
def get_pending_requests():
    """Fetch all pending requests."""
    try:
        print("reached here")
        requests = list(db.requests.find({"status": "pending"}))
        print("reached here", requests)
        return jsonify([serialize_id(req) for req in requests]), 200
    except Exception as e:
        print(f"Error fetching pending requests: {e}")
        # Fallback to mock data
        mock_pending = [r for r in mock_data.MOCK_REQUESTS if r['status'] == 'pending']
        return jsonify(mock_pending), 200


@bp.route('/<request_id>/approve', methods=['POST'])
@jwt_required()
def approve_request(request_id):
    """Approve a request."""
    try:
        # Find the request
        req = db.requests.find_one({"_id": ObjectId(request_id)})
        if not req:
            return jsonify({"error": "Request not found"}), 404
        if req['type'] == 'instructor_account':
            # Create a new instructor account
            user_data = req['user_data']
            hashed_password = bcrypt.generate_password_hash(user_data['password']).decode('utf-8')
            new_user = {
                "email": user_data['email'],
                "password": hashed_password,
                "name": user_data['name'],
                "role": "instructor",
                "created_at": datetime.utcnow()
            }
            db.users.insert_one(new_user)
        # Update the request status
        db.requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": {"status": "approved", "updated_at": datetime.utcnow()}}
        )
        return jsonify({"message": "Request approved successfully"}), 200
    except Exception as e:
        print(f"Error approving request: {e}")
        return jsonify({"error": "Failed to approve request"}), 500


@bp.route('/<request_id>/deny', methods=['POST'])
@jwt_required()
def deny_request(request_id):
    """Deny a request."""
    try:
        result = db.requests.update_one(
            {"_id": ObjectId(request_id)},
            {"$set": {"status": "denied", "updated_at": datetime.utcnow()}}
        )
        if result.modified_count == 0:
            return jsonify({"error": "Request not found"}), 404
        return jsonify({"message": "Request denied successfully"}), 200
    except Exception as e:
        print(f"Error denying request: {e}")
        return jsonify({"error": "Failed to deny request"}), 500


@bp.route('', methods=['POST'])
def create_request():
    """Create a new request."""
    data = request.get_json()
    try:
        new_request = {
            **data,
            "status": "pending",
            "created_at": datetime.utcnow()
        }
        result = db.requests.insert_one(new_request)
        created_request = db.requests.find_one({"_id": result.inserted_id})
        return jsonify(serialize_id(created_request)), 201
    except Exception as e:
        print(f"Error creating request: {e}")
        return jsonify({"error": "Failed to create request"}), 500
