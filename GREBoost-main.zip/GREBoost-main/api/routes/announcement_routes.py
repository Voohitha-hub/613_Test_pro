from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from bson.objectid import ObjectId
from datetime import datetime
from app import mongo

bp = Blueprint('announcements', __name__, url_prefix='/api/announcements')

@bp.route('/course/<string:course_id>', methods=['GET'])
# @jwt_required()
def get_announcements(course_id):
    # Query the 'announcements' collection for a specific course
    announcements = mongo.db.announcements.find({"course_id": course_id})

    return jsonify([
        {
            'id': str(ann['_id']),
            'courseId': str(ann['course_id']),
            'title': ann['title'],
            'content': ann['content'],
            'date': ann['created_at'].isoformat() if 'created_at' in ann else None
        }
        for ann in announcements
    ]), 200

@bp.route('/course/<string:course_id>', methods=['POST'])
@jwt_required()
def create_announcement(course_id):
    user_id = get_jwt_identity()
    data = request.get_json()

    # Create a new announcement document
    new_announcement = {
        "course_id": course_id,
        "title": data['title'],
        "content": data['content'],
        "created_by": ObjectId(user_id),
        "created_at": datetime.utcnow()
    }

    # Insert the announcement into the collection
    result = mongo.db.announcements.insert_one(new_announcement)

    # Fetch the newly inserted announcement
    inserted_announcement = mongo.db.announcements.find_one({"_id": result.inserted_id})

    return jsonify({
        'id': str(inserted_announcement['_id']),
        'courseId': str(inserted_announcement['course_id']),
        'title': inserted_announcement['title'],
        'content': inserted_announcement['content'],
        'createdBy': mongo.db.users.find_one({"_id": ObjectId(user_id)})['name'],
        'date': inserted_announcement['created_at'].isoformat()
    }), 201

@bp.route('/<string:announcement_id>', methods=['DELETE'])
@jwt_required()
def delete_announcement(announcement_id):
    # Delete the announcement by its ID
    result = mongo.db.announcements.delete_one({"_id": ObjectId(announcement_id)})

    if result.deleted_count == 0:
        return jsonify({'message': 'Announcement not found'}), 404

    return jsonify({'message': 'Announcement deleted successfully'}), 200
